/**
 * Altura útil da tela. Alguns visualizadores (pré-visualização de arquivos em apps,
 * webviews que crescem com a página) informam uma altura muito maior que a tela real,
 * o que deixava o envelope gigante e cortado. Aqui a altura é limitada à tela do aparelho.
 */
export function installViewport(): void {
  const root = document.documentElement;
  const apply = () => {
    const ih = window.innerHeight || 0;
    const vv = window.visualViewport?.height || ih;
    const sh = (window.screen && (window.screen.availHeight || window.screen.height)) || ih;
    const sw = (window.screen && window.screen.width) || window.innerWidth;
    let h = Math.min(ih, vv) || sh;
    let clamped = false;
    // webview com altura "infinita": maior que a tela física ou desproporcional à largura
    if (h > sh * 1.15 || (window.innerWidth <= sw * 1.05 && h > window.innerWidth * 2.6)) {
      h = Math.min(sh, Math.round(window.innerWidth * 2.17));
      clamped = true;
    }
    root.style.setProperty('--app-h', `${h}px`);
    root.classList.toggle('vp-clamped', clamped);
  };
  apply();
  window.addEventListener('resize', apply);
  window.visualViewport?.addEventListener('resize', apply);
}
