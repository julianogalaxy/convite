import { INVITATION as C } from './invitation';

/**
 * Personalização por paciente, vinda do link.
 * Formato gerado pelo gerador:  #n=Maria%20Clara&d=2026-12-12&h=14:30
 * Também aceita ?para=Maria&data=2026-12-12&hora=14:30 e o formato antigo #Maria.
 * O fragmento (#) não é enviado a servidores nem fica em registros de acesso.
 */
export interface Personal {
  name: string;
  /** AAAA-MM-DD */
  date: string;
  /** HH:MM */
  time: string;
  /** valor em centavos como texto ("89000"), vazio se não houver */
  price?: string;
  /** descrição do valor (ex.: "Condição exclusiva no Botox Day") */
  offer?: string;
}

/** "890", "890,00", "1.290,50", "R$ 1290.5" -> centavos; '' se inválido */
export function parsePrice(raw: string): string {
  let t = (raw || '').replace(/[^\d.,]/g, '');
  if (!t) return '';
  const lastSep = Math.max(t.lastIndexOf(','), t.lastIndexOf('.'));
  let cents: number;
  if (lastSep >= 0 && t.length - lastSep - 1 <= 2 && t.length - lastSep - 1 > 0) {
    const int = t.slice(0, lastSep).replace(/[.,]/g, '') || '0';
    const dec = t.slice(lastSep + 1).padEnd(2, '0');
    cents = Number(int) * 100 + Number(dec);
  } else {
    cents = Number(t.replace(/[.,]/g, '')) * 100;
  }
  if (!Number.isFinite(cents) || cents <= 0 || cents > 10000000) return '';
  return String(Math.round(cents));
}

export function formatPrice(cents: string): string {
  const n = Number(cents) / 100;
  try { return n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); } catch { return `R$ ${n.toFixed(2).replace('.', ',')}`; }
}

export function cleanOffer(raw: string): string {
  return (raw || '').replace(/[<>{}&#=]/g, '').replace(/\s+/g, ' ').trim().slice(0, 80);
}

export interface EventInfo {
  start: string;
  end: string;
  /** "às 14h30" ou o horário geral do evento */
  hours: string;
  agendaNote: string;
  personalized: boolean;
}

const SMALL: Record<string, 1> = { da: 1, de: 1, di: 1, do: 1, das: 1, dos: 1, e: 1 };

export function cleanName(raw: string): string {
  const s = (raw || '').replace(/[-_+.]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (s.length < 2 || s.length > 40 || !/^[A-Za-zÀ-ÖØ-öø-ÿ' ]+$/.test(s)) return '';
  return s.toLowerCase().split(' ').map((w, i) => (i > 0 && SMALL[w] ? w : w.charAt(0).toUpperCase() + w.slice(1))).join(' ');
}

export const validDate = (d: string) => /^\d{4}-\d{2}-\d{2}$/.test(d) && !Number.isNaN(new Date(`${d}T12:00:00-03:00`).getTime());
export const validTime = (t: string) => /^([01]\d|2[0-3]):[0-5]\d$/.test(t);

export function readPersonal(): Personal {
  const out: Personal = { name: '', date: '', time: '', price: '', offer: '' };
  let hash = '';
  try { hash = decodeURIComponent((location.hash || '').slice(1)); } catch { /* ignora */ }
  let q: URLSearchParams | null = null;
  try { q = new URLSearchParams(location.search); } catch { /* ignora */ }
  if (hash.includes('=')) {
    const p = new URLSearchParams(hash);
    out.name = p.get('n') || p.get('para') || '';
    out.date = p.get('d') || p.get('data') || '';
    out.time = p.get('h') || p.get('hora') || '';
    out.price = p.get('v') || '';
    out.offer = p.get('c') || '';
  } else if (/^[^.]+\.\d{4}(\.|$)/.test(hash)) {
    Object.assign(out, parseCompact(hash));
  } else if (hash && hash !== 'gerador') {
    out.name = hash;
  }
  if (q) {
    out.name = out.name || q.get('para') || q.get('n') || '';
    out.date = out.date || q.get('data') || q.get('d') || '';
    out.time = out.time || q.get('hora') || q.get('h') || '';
    out.price = out.price || q.get('valor') || q.get('v') || '';
    out.offer = out.offer || q.get('c') || '';
  }
  const price = /^\d+$/.test(out.price || '') ? out.price! : parsePrice(out.price || '');
  return { name: cleanName(out.name), date: validDate(out.date) ? out.date : '', time: validTime(out.time) ? out.time : '', price, offer: price ? cleanOffer(out.offer || '') : '' };
}

/**
 * Formato curto, legível e sem cara de rastreamento:  #Juliano-Motta.0512.1030.x2kpc
 *   nome (hífen no lugar do espaço) . DDMM . HHMM (opcional) . x + valor em centavos na base 36 (opcional)
 * O ano é o do evento (ou o seguinte, se a data já tiver passado há mais de 60 dias).
 */
function parseCompact(h: string): Partial<Personal> {
  const seg = h.split('.');
  const out: Partial<Personal> = { name: seg[0] };
  const dm = seg[1] || '';
  if (/^\d{4}$/.test(dm)) {
    let y = Number(C.event.start.slice(0, 4));
    const iso = (yy: number) => `${yy}-${dm.slice(2)}-${dm.slice(0, 2)}`;
    if (validDate(iso(y)) && new Date(`${iso(y)}T12:00:00-03:00`).getTime() < Date.now() - 60 * 864e5) y += 1;
    out.date = iso(y);
  }
  for (const s of seg.slice(2)) {
    if (/^\d{4}$/.test(s)) out.time = `${s.slice(0, 2)}:${s.slice(2)}`;
    else if (/^x[0-9a-z]+$/i.test(s)) { const c = parseInt(s.slice(1), 36); if (c > 0) out.price = String(c); }
  }
  return out;
}

/** Link curto quando possível; descrição de valor fora do padrão usa o formato completo. */
export function buildHash(p: Personal): string {
  const n = cleanName(p.name);
  const offer = cleanOffer(p.offer || '');
  const customOffer = !!(p.price && offer && offer !== C.offerTitle);
  if (n && validDate(p.date) && !customOffer) {
    const [, mo, d] = p.date.split('-');
    let h = `#${n.replace(/ /g, '-')}.${d}${mo}`;
    if (validTime(p.time)) h += `.${p.time.replace(':', '')}`;
    if (p.price && /^\d+$/.test(p.price)) h += `.x${Number(p.price).toString(36)}`;
    return h;
  }
  return buildLongHash(p);
}

export function buildLongHash(p: Personal): string {
  const parts: string[] = [];
  const n = cleanName(p.name);
  if (n) parts.push(`n=${encodeURIComponent(n)}`);
  if (validDate(p.date)) parts.push(`d=${p.date}`);
  if (validTime(p.time)) parts.push(`h=${p.time}`);
  if (p.price && /^\d+$/.test(p.price)) {
    parts.push(`v=${p.price}`);
    const o = cleanOffer(p.offer || '');
    if (o) parts.push(`c=${encodeURIComponent(o)}`);
  }
  return parts.length ? `#${parts.join('&')}` : '';
}

/** "14:30" -> "14h30"; "09:00" -> "9h" */
export function timeLabel(t: string): string {
  const [h, m] = t.split(':').map(Number);
  return `${h}h${m ? String(m).padStart(2, '0') : ''}`;
}

export function eventFor(p: Personal): EventInfo {
  const E = C.event;
  if (!p.date && !p.time) return { ...E, personalized: false };
  const date = p.date || E.start.slice(0, 10);
  if (p.time) {
    const start = new Date(`${date}T${p.time}:00-03:00`);
    const end = new Date(start.getTime() + C.appointmentMinutes * 60000);
    return {
      start: start.toISOString(),
      end: end.toISOString(),
      hours: `às ${timeLabel(p.time)}`,
      agendaNote: C.personalNote,
      personalized: true,
    };
  }
  return { start: `${date}${E.start.slice(10)}`, end: `${date}${E.end.slice(10)}`, hours: E.hours, agendaNote: E.agendaNote, personalized: true };
}
