/**
 * Conteúdo do convite. Edite aqui para outras campanhas: nenhum texto abaixo
 * interfere na lógica das animações.
 */
export interface Procedure {
  title: string;
  detail: string;
}

export interface InvitationConfig {
  closedMessage: string;
  eyebrow: string;
  campaign: string;
  edition: string;
  welcome: string;
  experienceTitle: string;
  experienceText: string;
  professional: {
    name: string;
    area: string;
    registry: string;
    specialty: string;
    instagram: string;
  };
  proceduresTitle: string;
  procedures: Procedure[];
  proceduresNote: string;
  event: {
    start: string; // ISO com fuso de Brasília
    end: string;
    hours: string;
    agendaNote: string;
  };
  clinic: {
    name: string;
    street: string;
    district: string;
    zip: string;
    fullAddress: string;
    croRegistration: string; // nº de inscrição da clínica no CRO-SP (aparece quando preenchido)
  };
  /** duração do atendimento individual, usada no lembrete de agenda (min) */
  appointmentMinutes: number;
  /** valor individual (gerador): título padrão e observação exibidos no convite */
  offerTitle: string;
  offerNote: string;
  /** texto exibido quando o convite traz um horário reservado */
  personalNote: string;
  whatsapp: { number: string; display: string; message: (guest: string, day: number, month: string, time: string) => string };
  /** mensagem que a clínica envia com o link (gerador). {nome}, {dia}, {horario}, {condicao}, {link}; também {data}, {hora}, {valor} */
  shareTemplate: string;
  legal: string;
}

export const INVITATION: InvitationConfig = {
  closedMessage: 'Você está convidada para uma experiência especial',
  eyebrow: 'Convite especial',
  campaign: 'Botox Day',
  edition: 'Edição de fim de ano',
  welcome: 'Uma experiência especial foi preparada para você.',
  experienceTitle: 'Seu sorriso merece uma atenção especial.',
  experienceText:
    'Reservamos um dia da nossa agenda para a aplicação de toxina botulínica, com avaliação individual, tempo para conversar sem pressa e o compromisso com a naturalidade que guia o nosso trabalho.',
  professional: {
    name: 'Dra. Elisângela Mota Magalhães',
    area: 'Odontologia e Harmonização Orofacial',
    registry: 'CRO-SP 98531',
    specialty: 'Especialista em Harmonização Orofacial',
    instagram: '@elisangelarmagalhes',
  },
  proceduresTitle: 'Neste dia',
  procedures: [
    { title: 'Linhas de expressão', detail: 'Toxina botulínica no terço superior da face: testa, entre as sobrancelhas e ao redor dos olhos.' },
    { title: 'Sorriso gengival', detail: 'Suavização da exposição da gengiva ao sorrir, quando indicada.' },
    { title: 'Bruxismo e apertamento', detail: 'Aplicação no músculo masseter para aliviar a força de apertamento.' },
    { title: 'Avaliação facial', detail: 'Análise individual antes de qualquer aplicação, com plano conversado com você.' },
  ],
  proceduresNote: 'A indicação de cada procedimento é definida em avaliação clínica individual.',
  event: {
    start: '2026-12-12T09:00:00-03:00',
    end: '2026-12-12T18:00:00-03:00',
    hours: 'das 9h às 18h',
    agendaNote: 'Agenda exclusiva com horários limitados. Reserve o seu antes da virada do ano.',
  },
  clinic: {
    name: 'Odontologia Reabilitação Oral e Estética',
    street: 'R. Eliza Laurinda da Silva, 284',
    district: 'Jardim Santana, Hortolândia/SP',
    zip: 'CEP 13184-553',
    fullAddress: 'R. Eliza Laurinda da Silva, 284, Jardim Santana, Hortolândia/SP, CEP 13184-553',
    croRegistration: '',
  },
  appointmentMinutes: 60,
  offerTitle: 'Condição exclusiva para você',
  offerNote: 'Valor individual, válido para o Botox Day e garantido antes do reajuste de 2027.',
  personalNote: 'Este horário foi reservado para você. Se precisar remarcar, é só nos chamar no WhatsApp.',
  shareTemplate:
    'Olá, {nome}! ✨\n\n' +
    'Nós, do consultório Odontologia Reabilitação Oral e Estética, junto com a Dra. Elisângela Mota Magalhães, preparamos um convite especial para você: *Botox Day* 💛\n\n' +
    '📅 {dia}\n' +
    '⏰ {horario}\n' +
    '📍 R. Eliza Laurinda da Silva, 284 · Jardim Santana, Hortolândia\n\n' +
    '{condicao}' +
    'Para ver todos os detalhes, é só abrir o seu convite 💌\n' +
    '{link}\n\n' +
    'Qualquer dúvida, responda esta mensagem. Será um prazer receber você! 😊',
  whatsapp: {
    number: '551941220163',
    display: '(19) 4122-0163',
    message: (guest, day, month, time) =>
      (guest ? `Olá! Sou ${guest}. ` : 'Olá! ') +
      (time
        ? `Recebi o convite do Botox Day e quero confirmar meu horário de ${day} de ${month}, ${time}.`
        : `Recebi o convite do Botox Day de fim de ano e quero reservar meu horário para ${day} de ${month}.`),
  },
  legal:
    'Responsável técnica: Dra. Elisângela Rodrigues Mota Magalhães, CRO-SP 98531, especialista em Harmonização Orofacial.',
};
