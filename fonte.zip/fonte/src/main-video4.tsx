import { StrictMode, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ArrowLeft } from 'lucide-react';
import { VideoIntroV4 } from './components/VideoIntroV4';
import { Generator } from './components/Generator';
import { readPersonal, type Personal } from './config/personalization';
import './styles.css';
import { installViewport } from './viewport';
import cotton from './assets/cotton.webp';
import envPaper from './assets/env-paper.webp';
import cardPaper from './assets/card-paper.webp';

installViewport();
const root = document.documentElement.style;
root.setProperty('--paper-grain', `url(${cotton})`);
root.setProperty('--env-paper', `url(${envPaper})`);
root.setProperty('--card-paper', `url(${cardPaper})`);

/** Gerador: link com #gerador, ?gerador, ou página publicada com data-mode="gerador". */
function wantsGenerator(): boolean {
  try {
    return document.getElementById('root')?.dataset.mode === 'gerador' || /gerador/.test(location.hash) || /[?&]gerador\b/.test(location.search);
  } catch { return false; }
}

function AppV4() {
  const [generator] = useState(wantsGenerator);
  const [personal] = useState(readPersonal);
  const [preview, setPreview] = useState<{ p: Personal; k: number } | null>(null);
  if (!generator) return <VideoIntroV4 personal={personal} />;
  return (
    <>
      <div style={preview ? { display: 'none' } : undefined}>
        <Generator onPreview={(p) => setPreview({ p, k: Date.now() })} />
      </div>
      {preview && (
        <div className="has-preview">
          <VideoIntroV4 key={preview.k} personal={preview.p} />
          <button type="button" className="gen-back" onClick={() => setPreview(null)}>
            <ArrowLeft size={15} strokeWidth={1.6} aria-hidden="true" /><span>Voltar ao gerador</span>
          </button>
        </div>
      )}
    </>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AppV4 />
  </StrictMode>,
);
