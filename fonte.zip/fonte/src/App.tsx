import { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { EnvelopeScene } from './components/EnvelopeScene';
import { Generator } from './components/Generator';
import { readPersonal, type Personal } from './config/personalization';

/** Gerador: link com #gerador, ?gerador, ou build publicado com data-mode="gerador". */
function wantsGenerator(): boolean {
  try {
    return document.getElementById('root')?.dataset.mode === 'gerador' || /gerador/.test(location.hash) || /[?&]gerador\b/.test(location.search);
  } catch { return false; }
}

export default function App() {
  const [generator] = useState(wantsGenerator);
  const [preview, setPreview] = useState<{ p: Personal; k: number } | null>(null);
  const [personal] = useState(readPersonal);

  if (!generator) return <EnvelopeScene personal={personal} />;
  // o gerador continua montado durante a prévia, para não perder o que foi digitado
  return (
    <>
      <div hidden={!!preview} style={preview ? { display: 'none' } : undefined}>
        <Generator onPreview={(p) => setPreview({ p, k: Date.now() })} />
      </div>
      {preview && (
        <div className="has-preview">
          <EnvelopeScene key={preview.k} personal={preview.p} />
          <button type="button" className="gen-back" onClick={() => setPreview(null)}>
            <ArrowLeft size={15} strokeWidth={1.6} aria-hidden="true" /><span>Voltar ao gerador</span>
          </button>
        </div>
      )}
    </>
  );
}
