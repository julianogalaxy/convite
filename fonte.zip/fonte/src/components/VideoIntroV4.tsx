import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { INVITATION } from '../config/invitation';
import { eventFor, type Personal } from '../config/personalization';
import { InvitationCard } from './InvitationCard';
import { InvitationContent } from './InvitationContent';
import videoData from '../assets/video/abertura-v4.mp4';
import poster from '../assets/video/poster-v4.webp';

/**
 * Versão 4: abertura em vídeo real (segundo filme). Ao tocar, o vídeo do envelope abrindo roda em tela cheia.
 * Quando o cartão pousa sobre o envelope, a carta do convite aparece exatamente sobre ele
 * e se expande até virar a página, sem corte nem troca de tela.
 */

/** Ajustes da transição (tempos em segundos do vídeo e da animação). */
const V = {
  w: 720, h: 1280,
  /** posição do cartão no vídeo (px do vídeo) quando ele já pousou */
  card: { x: 144, y: 333, w: 432, h: 592 },
  /** instante do vídeo em que a carta do convite assume o lugar do cartão */
  handoff: 5.1,
  /** segurança: se o vídeo não avançar, segue para o convite */
  stallTimeout: 5,
  appear: 0.45,
  expand: 1.35,
  reveal: { duration: 1.1, stagger: 0.12, y: 16 },
};

type Phase = 'idle' | 'playing' | 'revealing' | 'completed';

/** Vídeo embutido em base64 vira Blob: o Safari reproduz blob: com segurança, data: nem sempre. */
function useVideoSrc(): string {
  return useMemo(() => {
    try {
      const b64 = videoData.slice(videoData.indexOf(',') + 1);
      const bin = atob(b64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return URL.createObjectURL(new Blob([bytes], { type: 'video/mp4' }));
    } catch {
      return videoData;
    }
  }, []);
}

function offsetWithin(el: HTMLElement, root: HTMLElement): number {
  let y = 0;
  let n: HTMLElement | null = el;
  while (n && n !== root) { y += n.offsetTop; n = n.offsetParent as HTMLElement | null; }
  return y;
}

function setClip(el: HTMLElement, bottom: number): void {
  const v = bottom > 0.5 ? `inset(0px 0px ${bottom.toFixed(1)}px 0px)` : 'none';
  el.style.clipPath = v;
  el.style.setProperty('-webkit-clip-path', v);
}

export function VideoIntroV4({ personal }: { personal: Personal }) {
  const [phase, setPhase] = useState<Phase>('idle');
  const [muted, setMuted] = useState(false);
  const src = useVideoSrc();
  const event = useMemo(() => eventFor(personal), [personal]);
  const reduced = useMemo(() => /[?&]semanimacao\b/.test(window.location.search), []);

  const sceneRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const letter = useRef<HTMLDivElement>(null);
  const overlay = useRef<HTMLDivElement>(null);
  const shadow = useRef<HTMLDivElement>(null);
  const light = useRef<HTMLDivElement>(null);
  const tl = useRef<gsap.core.Timeline | null>(null);
  const started = useRef(false);

  const items = () => Array.from(letter.current?.querySelectorAll<HTMLElement>('[data-reveal]') ?? []);

  /** cartão do vídeo em coordenadas da tela (o vídeo cobre o quadro com object-fit: cover) */
  const geometry = useCallback(() => {
    const fr = frameRef.current!, l = letter.current!;
    const FW = fr.clientWidth, FH = fr.clientHeight, fx = fr.offsetLeft;
    const s = Math.max(FW / V.w, FH / V.h);
    const ox = fx + (FW - V.w * s) / 2, oy = (FH - V.h * s) / 2;
    const card = { x: ox + V.card.x * s, y: oy + V.card.y * s, w: V.card.w * s, h: V.card.h * s };
    const LW = l.offsetWidth, LX = l.offsetLeft, H = l.offsetHeight;
    const k = card.w / LW;
    const visible = Math.min(card.h, H * k);
    return { k, x: card.x - LX, y: card.y, clip: Math.max(0, H - visible / k), card };
  }, []);

  const reset = useCallback(() => {
    tl.current?.kill();
    started.current = false;
    const g = geometry();
    gsap.set(letter.current, { transformOrigin: '0% 0%', x: g.x, y: g.y, scale: g.k, opacity: 0 });
    setClip(letter.current!, g.clip);
    gsap.set(shadow.current, { left: g.card.x, top: g.card.y, width: g.card.w, height: g.card.h, opacity: 0 });
    gsap.set(frameRef.current, { scale: 1, opacity: 1, filter: 'none' });
    gsap.set(overlay.current, { opacity: 1, y: 0 });
    gsap.set(light.current, { yPercent: -60, opacity: 0 });
    gsap.set(items(), { opacity: 0, y: V.reveal.y });
    gsap.set(letter.current!.querySelector('.content'), { opacity: 0 });
    const v = videoRef.current;
    if (v) { try { v.pause(); v.currentTime = 0; } catch { /* ignora */ } }
  }, [geometry]);

  useLayoutEffect(() => { reset(); }, [reset]);

  useEffect(() => {
    const onResize = () => { if (!started.current) reset(); };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [reset]);

  /** a carta assume o lugar do cartão e se expande até virar a página */
  const handoff = useCallback(() => {
    if (tl.current) return;
    const l = letter.current!;
    const g = geometry();
    const clip = { b: g.clip };
    const H = l.offsetHeight;
    const first = items().filter((el) => offsetWithin(el, l) < H * 0.9);
    setPhase('revealing');
    const t = gsap.timeline({ onComplete: () => { setPhase('completed'); videoRef.current?.pause(); } });
    t.set(l, { x: g.x, y: g.y, scale: g.k })
      .to(shadow.current, { opacity: 1, duration: V.appear, ease: 'power1.out' }, 0)
      // o papel cobre o texto do vídeo quase de imediato; a impressão do convite surge em seguida
      .to(l, { opacity: 1, duration: 0.2, ease: 'power1.out' }, 0)
      .to(l.querySelector('.content'), { opacity: 1, duration: 0.6, ease: 'power1.inOut' }, 0.15)
      .call(() => videoRef.current?.pause(), [], V.appear)
      .addLabel('expand', V.appear - 0.1)
      .to(l, { x: 0, y: 0, scale: 1, duration: V.expand, ease: 'power3.inOut' }, 'expand')
      .to(clip, { b: 0, duration: V.expand, ease: 'power3.inOut', onUpdate: () => setClip(l, clip.b) }, 'expand')
      .to(shadow.current, { opacity: 0, duration: 0.5 }, 'expand')
      .to(frameRef.current, { scale: 1.12, opacity: 0, duration: V.expand, ease: 'power2.in' }, 'expand+=0.1')
      .to(first, { opacity: 1, y: 0, duration: V.reveal.duration, stagger: V.reveal.stagger, ease: 'power2.out' }, `expand+=${V.expand - 0.3}`);
    tl.current = t;
  }, [geometry]);

  const start = useCallback(() => {
    if (phase !== 'idle' || started.current) return;
    started.current = true;
    try { navigator.vibrate?.(12); } catch { /* sem vibração */ }
    gsap.to(overlay.current, { opacity: 0, y: 8, duration: 0.6, ease: 'power1.in' });
    if (reduced) { handoff(); return; }
    setPhase('playing');
    const v = videoRef.current!;
    v.muted = muted;
    const p = v.play();
    if (p && typeof p.catch === 'function') {
      p.catch(() => { v.muted = true; setMuted(true); v.play().catch(() => handoff()); });
    }
  }, [phase, reduced, handoff, muted]);

  // acompanha o vídeo quadro a quadro; segue para o convite no instante do cartão pousado
  useEffect(() => {
    if (phase !== 'playing') return;
    const v = videoRef.current!;
    let raf = 0, last = -1, lastMove = performance.now();
    const tick = () => {
      const t = v.currentTime;
      if (t !== last) { last = t; lastMove = performance.now(); }
      if (t >= V.handoff || v.ended) { handoff(); return; }
      if (performance.now() - lastMove > V.stallTimeout * 1000) { handoff(); return; }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    // se o navegador recusar o blob:, tenta uma vez a fonte data: antes de seguir para o convite
    let retried = false;
    const onErr = () => {
      if (!retried && v.src.startsWith('blob:')) {
        retried = true; lastMove = performance.now();
        v.src = videoData; v.load(); v.play().catch(() => handoff());
        return;
      }
      handoff();
    };
    v.addEventListener('error', onErr);
    return () => { cancelAnimationFrame(raf); v.removeEventListener('error', onErr); };
  }, [phase, handoff]);

  // blocos abaixo da primeira tela entram com a rolagem
  useEffect(() => {
    if (phase !== 'completed' || !letter.current) return;
    const l = letter.current;
    const pending = items().filter((el) => Number(getComputedStyle(el).opacity) < 0.99);
    if (!pending.length) return;
    if (typeof IntersectionObserver === 'undefined') { gsap.set(pending, { opacity: 1, y: 0 }); return; }
    const io = new IntersectionObserver((entries) => {
      entries.filter((e) => e.isIntersecting).forEach((e, i) => {
        io.unobserve(e.target);
        gsap.to(e.target, { opacity: 1, y: 0, duration: V.reveal.duration, delay: i * V.reveal.stagger, ease: 'power2.out' });
      });
    }, { root: l, rootMargin: '0px 0px -8% 0px', threshold: 0.12 });
    pending.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [phase]);

  const restart = useCallback(() => {
    if (phase !== 'completed') return;
    letter.current?.scrollTo({ top: 0 });
    setPhase('idle');
    requestAnimationFrame(() => {
      reset();
      gsap.fromTo(sceneRef.current, { opacity: 0 }, { opacity: 1, duration: 0.6, ease: 'power1.out' });
    });
  }, [phase, reset]);

  // gancho de validação automatizada (?qa)
  useEffect(() => {
    if (!/[?&]qa\b/.test(window.location.search)) return;
    (window as unknown as { __vid: unknown }).__vid = { phase, video: videoRef.current, handoff };
  });

  const guest = personal.name;
  const completed = phase === 'completed';
  return (
    <div className={`scene vscene phase-${phase}`} ref={sceneRef} data-phase={phase}>
      <svg className="defs" aria-hidden="true" focusable="false">
        <defs>
          <linearGradient id="gFrame" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#B48D45" /><stop offset=".3" stopColor="#E9D296" /><stop offset=".55" stopColor="#A88034" /><stop offset=".8" stopColor="#D6B46A" /><stop offset="1" stopColor="#9C7535" />
          </linearGradient>
          <linearGradient id="gMark" gradientUnits="userSpaceOnUse" x1="480" y1="0" x2="1230" y2="724">
            <stop offset="0" stopColor="#E4C67C" /><stop offset=".35" stopColor="#F4E2AE" /><stop offset=".6" stopColor="#C39A4C" /><stop offset="1" stopColor="#8E6A2C" />
          </linearGradient>
        </defs>
      </svg>
      <div className="backdrop" aria-hidden="true" />

      <div className="vframe" ref={frameRef} aria-hidden="true">
        <video ref={videoRef} className="vvideo" src={src} poster={poster} playsInline preload="auto" muted={muted} />
      </div>

      <div className="vshadow" ref={shadow} aria-hidden="true" />
      <div className="stage3d">
        <div className="rig">
          <InvitationCard ref={letter} lightRef={light} scrollable={completed}>
            <InvitationContent guest={guest} event={event} price={personal.price} offer={personal.offer} completed={completed} reduced={reduced} onRestart={restart} />
          </InvitationCard>
        </div>
      </div>

      <div className="voverlay" ref={overlay}>
        <p className="closed-msg vmsg">{guest ? `${guest}, você` : 'Você'} {INVITATION.closedMessage.replace(/^Você\s/, '')}</p>
      </div>

      {phase === 'idle' && (
        <>
          <p className="tap-hint vhint" aria-hidden="true"><span>Toque para abrir</span></p>
          <button className="hit" type="button" onClick={start} aria-label="Abrir o convite" />
        </>
      )}
      {phase === 'playing' && (
        <button type="button" className="vmute" onClick={() => { const v = videoRef.current; if (v) v.muted = !muted; setMuted(!muted); }} aria-label={muted ? 'Ativar som' : 'Desativar som'}>
          {muted ? 'Som desligado' : 'Som ligado'}
        </button>
      )}
    </div>
  );
}
