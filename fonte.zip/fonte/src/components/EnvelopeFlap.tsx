import { forwardRef, type ReactNode, type Ref } from 'react';

/** Aba superior articulada: face externa (papel), face interna (forro) e o selo preso à ponta.
 *  O contêiner usa preserve-3d; as faces escondem o verso (backface-visibility). */
interface Props {
  shadeRef: Ref<HTMLDivElement>;
  backShadeRef: Ref<HTMLDivElement>;
  children?: ReactNode; // selo
}

export const EnvelopeFlap = forwardRef<HTMLDivElement, Props>(function EnvelopeFlap({ shadeRef, backShadeRef, children }, ref) {
  return (
    <div className="env-flap" ref={ref}>
      <div className="flap-face flap-front">
        <div className="paper-face" />
        <svg className="edges" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true" focusable="false">
          <polyline points="7,3 50,92 93,3" fill="none" stroke="#B48D45" strokeOpacity=".55" strokeWidth="1" vectorEffect="non-scaling-stroke" />
          <polyline points="7,3.6 50,92.6 93,3.6" fill="none" stroke="#FFFFFF" strokeOpacity=".8" strokeWidth="1" vectorEffect="non-scaling-stroke" />
          <polyline points="0,0 50,100 100,0" fill="none" stroke="#FFFFFF" strokeOpacity=".9" strokeWidth="1.6" vectorEffect="non-scaling-stroke" />
        </svg>
        <div className="flap-shade" ref={shadeRef} />
      </div>
      <div className="flap-face flap-back">
        <div className="paper-face" />
        <div className="liner-foil" />
        <div className="liner" />
        <div className="flap-back-shade" ref={backShadeRef} />
      </div>
      {children}
    </div>
  );
});
