import { useCallback, useEffect, useLayoutEffect, useMemo, useReducer, useRef } from 'react';
import { gsap } from 'gsap';
import { createIdle, createOpeningTimeline, createReducedTimeline, measure, MOTION, setClosedState, splitRevealItems, type Phase, type SceneRefs } from '../animation/AnimationTimeline';
import { isAnimating, machine } from '../animation/stateMachine';
import { INVITATION } from '../config/invitation';
import { eventFor, type Personal } from '../config/personalization';
import { EnvelopeBody } from './EnvelopeBody';
import { EnvelopeFlap } from './EnvelopeFlap';
import { InvitationCard } from './InvitationCard';
import { InvitationContent } from './InvitationContent';
import { WaxSeal } from './WaxSeal';

/** Cena única: envelope 3D, carta e conteúdo convivem no mesmo espaço. */
export function EnvelopeScene({ personal }: { personal: Personal }) {
  const [phase, dispatch] = useReducer(machine, 'idle' as Phase);
  const guest = personal.name;
  const event = useMemo(() => eventFor(personal), [personal]);
  // A abertura é disparada pelo próprio toque da pessoa, então ela sempre roda.
  // Com "reduzir movimento" ativo no sistema, só os movimentos automáticos
  // (flutuação do envelope e brilhos em loop) são desligados.
  // Versão totalmente estática, sem abertura: acrescente ?semanimacao ao link.
  const calm = useMemo(() => {
    try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return false; }
  }, []);
  const reduced = useMemo(() => /[?&]semanimacao\b/.test(window.location.search), []);

  const sceneRef = useRef<HTMLDivElement>(null);
  const rig = useRef<HTMLDivElement>(null);
  const letter = useRef<HTMLDivElement>(null);
  const contactShadow = useRef<HTMLDivElement>(null);
  const body = useRef<HTMLDivElement>(null);
  const sideLeft = useRef<HTMLDivElement>(null);
  const sideRight = useRef<HTMLDivElement>(null);
  const bottom = useRef<HTMLDivElement>(null);
  const bottomShadow = useRef<HTMLDivElement>(null);
  const flapShadow = useRef<HTMLDivElement>(null);
  const flap = useRef<HTMLDivElement>(null);
  const flapShade = useRef<HTMLDivElement>(null);
  const seal = useRef<HTMLDivElement>(null);
  const sealGlow = useRef<HTMLDivElement>(null);
  const sealBase = useRef<HTMLDivElement>(null);
  const sealBaseHalf = useRef<HTMLDivElement>(null);
  const flapBackShade = useRef<HTMLDivElement>(null);
  const cardLight = useRef<HTMLDivElement>(null);
  const closedText = useRef<HTMLDivElement>(null);
  const opening = useRef<gsap.core.Timeline | null>(null);
  const idle = useRef<gsap.core.Timeline | null>(null);

  const refs = useCallback((): SceneRefs => ({
    rig: rig.current!, body: body.current!, letter: letter.current!, contactShadow: contactShadow.current!,
    sideLeft: sideLeft.current!, sideRight: sideRight.current!, bottom: bottom.current!, bottomShadow: bottomShadow.current!,
    flap: flap.current!, flapShade: flapShade.current!, flapShadow: flapShadow.current!, seal: seal.current!, sealGlow: sealGlow.current!,
    sealBase: sealBase.current!, sealBaseHalf: sealBaseHalf.current!, flapBackShade: flapBackShade.current!, cardLight: cardLight.current!,
    closedText: closedText.current!,
    revealItems: () => Array.from(letter.current?.querySelectorAll<HTMLElement>('[data-reveal]') ?? []),
  }), []);

  const prepare = useCallback(() => {
    const r = refs();
    opening.current?.kill();
    idle.current?.kill();
    const g = measure(r);
    setClosedState(r, g);
    if (!reduced && !calm) idle.current = createIdle(r);
    opening.current = (reduced ? createReducedTimeline : createOpeningTimeline)(r, g, (p) => dispatch({ type: 'PHASE', phase: p }));
  }, [refs, reduced, calm]);

  // a geometria depende da tela: com o envelope fechado, remede ao girar ou redimensionar
  const phaseRef = useRef<Phase>('idle');
  phaseRef.current = phase;
  useEffect(() => {
    let t = 0;
    const onResize = () => {
      window.clearTimeout(t);
      t = window.setTimeout(() => { if (phaseRef.current === 'idle') prepare(); }, 160);
    };
    window.addEventListener('resize', onResize);
    return () => { window.clearTimeout(t); window.removeEventListener('resize', onResize); };
  }, [prepare]);

  useLayoutEffect(() => {
    prepare();
    return () => { opening.current?.kill(); idle.current?.kill(); };
  }, [prepare]);

  const start = useCallback(() => {
    if (phase !== 'idle' || !opening.current) return;
    try { navigator.vibrate?.(12); } catch { /* sem vibração */ }
    dispatch({ type: 'TAP' });
    idle.current?.kill();
    opening.current.play(0);
  }, [phase]);

  const restart = useCallback(() => {
    if (phase !== 'completed') return;
    letter.current?.scrollTo({ top: 0 });
    dispatch({ type: 'RESTART' });
  }, [phase]);

  // ao voltar para 'idle' via reinício, remonta o envelope fechado com um fade suave
  useEffect(() => {
    if (phase === 'idle' && sceneRef.current?.dataset.played === '1') {
      prepare();
      gsap.fromTo(sceneRef.current, { opacity: 0 }, { opacity: 1, duration: 0.6, ease: 'power1.out' });
    }
    if (phase === 'completed' && sceneRef.current) sceneRef.current.dataset.played = '1';
  }, [phase, prepare]);

  // depois da abertura, os blocos abaixo da primeira tela entram conforme a rolagem
  useEffect(() => {
    if (phase !== 'completed' || !letter.current) return;
    const { onScroll } = splitRevealItems(refs());
    const pending = onScroll.filter((el) => Number(getComputedStyle(el).opacity) < 0.99);
    if (!pending.length) return;
    if (typeof IntersectionObserver === 'undefined') { gsap.set(pending, { opacity: 1, y: 0 }); return; }
    const io = new IntersectionObserver((entries) => {
      entries.filter((e) => e.isIntersecting).forEach((e, i) => {
        io.unobserve(e.target);
        gsap.to(e.target, { opacity: 1, y: 0, duration: MOTION.reveal.duration, delay: i * MOTION.reveal.stagger, ease: MOTION.reveal.ease });
      });
    }, { root: letter.current, rootMargin: '0px 0px -8% 0px', threshold: 0.12 });
    pending.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [phase, refs]);

  // gancho de validação automatizada (?qa): expõe a timeline para captura de etapas
  useEffect(() => {
    if (!/[?&]qa\b/.test(window.location.search)) return;
    (window as unknown as { __inv: unknown }).__inv = { get tl() { return opening.current; }, get phase() { return sceneRef.current?.dataset.phase; } };
  });

  const completed = phase === 'completed';
  return (
    <div className={`scene phase-${phase}`} ref={sceneRef} data-phase={phase} aria-busy={isAnimating(phase)}>
      <svg className="defs" aria-hidden="true" focusable="false">
        <defs>
          <linearGradient id="gFrame" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#B48D45" /><stop offset=".3" stopColor="#E9D296" /><stop offset=".55" stopColor="#A88034" /><stop offset=".8" stopColor="#D6B46A" /><stop offset="1" stopColor="#9C7535" />
          </linearGradient>
          <linearGradient id="gMark" gradientUnits="userSpaceOnUse" x1="480" y1="0" x2="1230" y2="724">
            <stop offset="0" stopColor="#E4C67C" /><stop offset=".35" stopColor="#F4E2AE" /><stop offset=".6" stopColor="#C39A4C" /><stop offset="1" stopColor="#8E6A2C" />
          </linearGradient>
        </defs>
      </svg>

      <div className="backdrop" aria-hidden="true" />

      <div className="closed-copy" ref={closedText}>
        <p className="closed-msg">{guest ? `${guest}, você` : 'Você'} {INVITATION.closedMessage.replace(/^Você\s/, '')}</p>
      </div>

      <div className="stage3d">
        <div className="rig" ref={rig}>
          <EnvelopeBody refs={{ body, sideLeft, sideRight, bottom, bottomShadow, flapShadow, sealBase }} sealBase={<WaxSeal ref={sealBaseHalf} half="base" />} />
          <div className="contact-shadow" ref={contactShadow} aria-hidden="true"><i /></div>
          <InvitationCard ref={letter} scrollable={completed} lightRef={cardLight}>
            <InvitationContent guest={guest} event={event} price={personal.price} offer={personal.offer} completed={completed} reduced={reduced} onRestart={restart} />
          </InvitationCard>
          <EnvelopeFlap ref={flap} shadeRef={flapShade} backShadeRef={flapBackShade}>
            <WaxSeal ref={seal} glowRef={sealGlow} half="top" />
          </EnvelopeFlap>
        </div>
      </div>

      {phase === 'idle' && (
        <>
          <p className="tap-hint" aria-hidden="true"><span>Toque no selo para abrir</span></p>
          <button className="hit" type="button" onClick={start} aria-label="Abrir o convite" />
        </>
      )}
    </div>
  );
}
