import type { ReactNode, RefObject } from 'react';

/** Corpo do envelope: fundo interno (forro), abas laterais, aba inferior e sombras de contato.
 *  Cada parte é uma camada independente posicionada em profundidade pela timeline. */
export interface BodyRefs {
  body: RefObject<HTMLDivElement | null>;
  sideLeft: RefObject<HTMLDivElement | null>;
  sideRight: RefObject<HTMLDivElement | null>;
  bottom: RefObject<HTMLDivElement | null>;
  bottomShadow: RefObject<HTMLDivElement | null>;
  flapShadow: RefObject<HTMLDivElement | null>;
  sealBase: RefObject<HTMLDivElement | null>;
}

/** Linhas de vinco e brilho das bordas livres (coordenadas em % do envelope). */
function Edges({ points, light = true }: { points: string; light?: boolean }) {
  return (
    <svg className="edges" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true" focusable="false">
      <polyline points={points} fill="none" stroke="#7A5A30" strokeOpacity=".22" strokeWidth="3" vectorEffect="non-scaling-stroke" />
      {light && <polyline points={points} fill="none" stroke="#FFFFFF" strokeOpacity=".9" strokeWidth="1.2" vectorEffect="non-scaling-stroke" />}
    </svg>
  );
}

export function EnvelopeBody({ refs, sealBase }: { refs: BodyRefs; sealBase: ReactNode }) {
  return (
    <>
      <div className="env-part env-body" ref={refs.body}>
        <div className="liner" />
        <div className="liner-depth" />
      </div>

      <div className="env-part env-side env-side-left" ref={refs.sideLeft}>
        <div className="paper-face" />
        <Edges points="0,0 55,50" />
      </div>
      <div className="env-part env-side env-side-right" ref={refs.sideRight}>
        <div className="paper-face" />
        <Edges points="100,0 45,50" />
      </div>

      <div className="env-part env-bottom-shadow" ref={refs.bottomShadow} aria-hidden="true"><i /></div>
      <div className="env-part env-bottom" ref={refs.bottom}>
        <div className="paper-face" />
        <Edges points="0,100 50,47 100,100" />
      </div>

      <div className="env-part env-flap-shadow" ref={refs.flapShadow} aria-hidden="true"><i /></div>

      {/* metade inferior do selo, presa à frente do envelope */}
      <div className="env-part env-seal-base" ref={refs.sealBase} aria-hidden="true">{sealBase}</div>
    </>
  );
}
