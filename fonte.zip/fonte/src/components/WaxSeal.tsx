import { forwardRef, useMemo } from 'react';

/** Selo de cera dourada em SVG, com o dente da marca em relevo. */
const TOOTH_L = 'M838 107L615 5L488 218L742 717L898 472L615 5';
const TOOTH_R = 'M808 470L1090 5L1220 218L968 717L660 241L1090 5';

function blobPath(cx: number, cy: number, r: number, seed: number): string {
  const pts: string[] = [];
  const n = 72;
  for (let i = 0; i <= n; i++) {
    const t = (i / n) * Math.PI * 2;
    const w =
      0.035 * Math.sin(3 * t + seed) + 0.022 * Math.sin(5 * t + 2.1 * seed) + 0.014 * Math.sin(8 * t + 1.3) +
      0.06 * Math.exp(-Math.pow(Math.atan2(Math.sin(t - 0.9), Math.cos(t - 0.9)) / 0.28, 2)) +
      0.05 * Math.exp(-Math.pow(Math.atan2(Math.sin(t - 4.3), Math.cos(t - 4.3)) / 0.3, 2));
    const rr = r * (1 + w);
    pts.push(`${(cx + Math.cos(t) * rr).toFixed(2)},${(cy + Math.sin(t) * rr).toFixed(2)}`);
  }
  return `M${pts.join(' L')} Z`;
}

/** O selo é desenhado duas vezes, idêntico e sobreposto: a metade de cima fica presa à aba,
 *  a de baixo ao corpo do envelope. Ao abrir, a cera trinca na linha irregular e cada metade segue sua peça. */
interface Props { glowRef?: React.Ref<HTMLDivElement>; half: 'top' | 'base'; }

export const WaxSeal = forwardRef<HTMLDivElement, Props>(function WaxSeal({ glowRef, half }, ref) {
  const outer = useMemo(() => blobPath(100, 100, 74, 0.6), []);
  const id = `ws-${half}`;
  return (
    <div className={`seal seal-${half}`} ref={ref}>
      {glowRef && <div className="seal-glow" ref={glowRef} aria-hidden="true" />}
      <div className="seal-body">
      <svg className="seal-svg" viewBox="0 0 200 200" aria-hidden="true" focusable="false">
        <defs>
          <radialGradient id={`${id}-wax`} cx="38%" cy="32%" r="78%">
            <stop offset="0" stopColor="#FBEBC0" />
            <stop offset=".28" stopColor="#E3C27A" />
            <stop offset=".62" stopColor="#C29A4E" />
            <stop offset=".86" stopColor="#9C7633" />
            <stop offset="1" stopColor="#7C5A22" />
          </radialGradient>
          <radialGradient id={`${id}-well`} cx="58%" cy="62%" r="70%">
            <stop offset="0" stopColor="#E9CD8A" />
            <stop offset=".6" stopColor="#CDA75B" />
            <stop offset="1" stopColor="#A47D37" />
          </radialGradient>
          <linearGradient id={`${id}-rim`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#8A6427" />
            <stop offset=".5" stopColor="#B8913F" stopOpacity=".2" />
            <stop offset="1" stopColor="#FFF4D2" />
          </linearGradient>
          <linearGradient id={`${id}-rim2`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#FFF6DC" />
            <stop offset=".5" stopColor="#E6CC86" stopOpacity=".1" />
            <stop offset="1" stopColor="#6E4F1C" />
          </linearGradient>
          <filter id={`${id}-emb`} x="-10%" y="-10%" width="120%" height="120%">
            <feGaussianBlur in="SourceAlpha" stdDeviation="1.6" result="b" />
            <feSpecularLighting in="b" surfaceScale="4" specularConstant=".9" specularExponent="22" lightingColor="#FFF6DA" result="s">
              <feDistantLight azimuth="225" elevation="42" />
            </feSpecularLighting>
            <feComposite in="s" in2="SourceAlpha" operator="in" result="s2" />
            <feOffset in="SourceAlpha" dx="1.2" dy="1.6" result="o" />
            <feGaussianBlur in="o" stdDeviation="1" result="ob" />
            <feFlood floodColor="#5C4012" floodOpacity=".55" />
            <feComposite in2="ob" operator="in" result="sh" />
            <feMerge><feMergeNode in="sh" /><feMergeNode in="SourceGraphic" /><feMergeNode in="s2" /></feMerge>
          </filter>
          <filter id={`${id}-wax-light`} x="-15%" y="-15%" width="130%" height="130%">
            <feGaussianBlur in="SourceAlpha" stdDeviation="4" result="b" />
            <feSpecularLighting in="b" surfaceScale="6" specularConstant=".75" specularExponent="16" lightingColor="#FFF4D6" result="s">
              <feDistantLight azimuth="225" elevation="48" />
            </feSpecularLighting>
            <feComposite in="s" in2="SourceAlpha" operator="in" result="s2" />
            <feMerge><feMergeNode in="SourceGraphic" /><feMergeNode in="s2" /></feMerge>
          </filter>
          <filter id={`${id}-drop`} x="-20%" y="-20%" width="140%" height="150%">
            <feDropShadow dx="1.5" dy="5" stdDeviation="4.5" floodColor="#4A3210" floodOpacity=".38" />
          </filter>
        </defs>
        <g filter={`url(#${id}-drop)`}>
          <path d={outer} fill={`url(#${id}-wax)`} filter={`url(#${id}-wax-light)`} />
        </g>
        <circle cx="100" cy="100" r="55" fill={`url(#${id}-well)`} />
        <circle cx="100" cy="100" r="55.5" fill="none" stroke={`url(#${id}-rim)`} strokeWidth="3" />
        <circle cx="100" cy="100" r="58.5" fill="none" stroke={`url(#${id}-rim2)`} strokeWidth="2" />
        <circle cx="100" cy="100" r="49" fill="none" stroke="#8E6A2C" strokeOpacity=".45" strokeWidth=".8" />
        <circle cx="100" cy="100.8" r="49" fill="none" stroke="#FFF4D2" strokeOpacity=".55" strokeWidth=".8" />
        <g filter={`url(#${id}-emb)`}>
          <g transform="translate(100 102) scale(.075) translate(-855 -361)">
            <path d={TOOTH_L} fill="none" stroke="#D8B567" strokeWidth="34" strokeLinecap="round" strokeLinejoin="round" />
            <path d={TOOTH_R} fill="none" stroke="#D8B567" strokeWidth="34" strokeLinecap="round" strokeLinejoin="round" />
          </g>
        </g>
        <ellipse cx="78" cy="62" rx="26" ry="12" fill="#FFFBEA" opacity=".28" transform="rotate(-28 78 62)" />
      </svg>
      <div className="seal-sheen" aria-hidden="true"><i /></div>
      </div>
    </div>
  );
});
