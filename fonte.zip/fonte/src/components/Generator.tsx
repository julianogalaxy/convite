import { useEffect, useMemo, useState } from 'react';
import { CalendarDays, Check, Clock, Copy, Eye, Link2, MessageCircle, User } from 'lucide-react';
import { INVITATION as C } from '../config/invitation';
import { buildHash, cleanName, cleanOffer, formatPrice, parsePrice, timeLabel, validDate, validTime, type Personal } from '../config/personalization';
import { DIAS, MESES } from '../hooks/useInvitationHooks';

/**
 * Gerador de convites personalizados (uso interno da clínica).
 * Monta o link com nome, data e horário da paciente e prepara a mensagem de WhatsApp.
 * Nada é enviado a servidor: o histórico fica só neste aparelho.
 */

const KEY_BASE = 'convite:endereco';
const KEY_HIST = 'convite-v2:historico';
const KEY_TPL = 'convite-v2:mensagem-3';
const KEY_OFFER = 'convite-v2:descricao-valor';

interface Sent { name: string; date: string; time: string; phone: string; price?: string; offer?: string; at: number }

const load = <T,>(k: string, fb: T): T => { try { const v = localStorage.getItem(k); return v ? (JSON.parse(v) as T) : fb; } catch { return fb; } };
const save = (k: string, v: unknown) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* armazenamento indisponível */ } };

function defaultBase(): string {
  try {
    const { protocol, hostname, origin, pathname } = window.location;
    if (!/^https?:$/.test(protocol) || /claude|usercontent|localhost|127\.0\.0\.1/.test(hostname)) return '';
    return origin + pathname;
  } catch { return ''; }
}

function dateLong(d: string): string {
  const x = new Date(`${d}T12:00:00-03:00`);
  const p = new Date(x.getTime() - 3 * 3600e3);
  return `${DIAS[p.getUTCDay()].toLowerCase()}, ${p.getUTCDate()} de ${MESES[p.getUTCMonth()].toLowerCase()}`;
}

function phoneDigits(raw: string): string {
  let d = raw.replace(/\D/g, '');
  if (d.startsWith('0')) d = d.replace(/^0+/, '');
  if (d.length === 10 || d.length === 11) d = '55' + d;
  return d;
}

async function copyText(t: string): Promise<boolean> {
  try { await navigator.clipboard.writeText(t); return true; } catch { /* fallback abaixo */ }
  try {
    const ta = document.createElement('textarea');
    ta.value = t; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select(); const ok = document.execCommand('copy'); ta.remove(); return ok;
  } catch { return false; }
}

export function Generator({ onPreview }: { onPreview: (p: Personal) => void }) {
  const [name, setName] = useState('');
  const [date, setDate] = useState(C.event.start.slice(0, 10));
  const [time, setTime] = useState('');
  const [phone, setPhone] = useState('');
  const [priceRaw, setPriceRaw] = useState('');
  const [offerRaw, setOfferRaw] = useState(() => load<string>(KEY_OFFER, C.offerTitle));
  const [base, setBase] = useState(() => load<string>(KEY_BASE, '') || defaultBase());
  const [tpl, setTpl] = useState(() => load<string>(KEY_TPL, C.shareTemplate));
  const [hist, setHist] = useState<Sent[]>(() => load<Sent[]>(KEY_HIST, []));
  const [flash, setFlash] = useState('');

  useEffect(() => { save(KEY_BASE, base.trim()); }, [base]);
  useEffect(() => { save(KEY_TPL, tpl); }, [tpl]);
  useEffect(() => { save(KEY_OFFER, offerRaw); }, [offerRaw]);
  useEffect(() => { save(KEY_HIST, hist.slice(0, 60)); }, [hist]);
  useEffect(() => { if (!flash) return; const t = window.setTimeout(() => setFlash(''), 1800); return () => window.clearTimeout(t); }, [flash]);

  const nm = cleanName(name);
  const price = parsePrice(priceRaw);
  const priceError = priceRaw.trim().length > 0 && !price;
  const personal: Personal = { name: nm, date: validDate(date) ? date : '', time: validTime(time) ? time : '', price, offer: price ? cleanOffer(offerRaw) : '' };
  const nameError = name.trim().length > 0 && !nm;
  const baseOk = /^https?:\/\/\S+$/i.test(base.trim());
  const link = baseOk ? base.trim().replace(/#.*$/, '') + buildHash(personal) : '';
  const firstName = nm.split(' ')[0] || '';

  const dayCap = personal.date ? dateLong(personal.date).replace(/^./, (c) => c.toUpperCase()) : 'Data a combinar';
  const message = useMemo(() => tpl
    .replace(/\{nome\}/g, firstName)
    .replace(/\{dia\}/g, dayCap)
    .replace(/\{horario\}/g, personal.time ? `Às ${timeLabel(personal.time)}` : C.event.hours.replace(/^./, (c) => c.toUpperCase()))
    .replace(/\{condicao\}/g, price ? '🎁 Reservamos uma condição exclusiva para você.\n\n' : '')
    .replace(/\{data\}/g, personal.date ? dateLong(personal.date) : 'no fim de ano')
    .replace(/\{hora\}/g, personal.time ? `, às ${timeLabel(personal.time)}` : '')
    .replace(/\{valor\}/g, price ? ` (${(cleanOffer(offerRaw) || C.offerTitle).toLowerCase()}: ${formatPrice(price)})` : '')
    .replace(/\{link\}/g, link || '[link do convite]'), [tpl, firstName, dayCap, personal.date, personal.time, link, price, offerRaw]);

  const pd = phoneDigits(phone);
  const phoneOk = !phone.trim() || (pd.length >= 12 && pd.length <= 13);
  const ready = !!nm && baseOk && phoneOk;
  const wa = `https://wa.me/${phone.trim() && phoneOk ? pd : ''}?text=${encodeURIComponent(message)}`;

  const record = () => setHist((h) => [{ name: nm, date: personal.date, time: personal.time, phone: pd, price, offer: personal.offer, at: Date.now() }, ...h]);
  const next = () => { setName(''); setTime(''); setPhone(''); setPriceRaw(''); };

  return (
    <div className="gen">
      <div className="gen-inner">
        <header className="gen-head">
          <p className="caps gold-deep">Uso interno da clínica</p>
          <h1><span className="gold">Gerador de convites</span></h1>
          <p className="gen-lead press">Preencha os dados da paciente, confira a prévia e envie. Cada link abre o convite com o nome, a data e o horário dela.</p>
        </header>

        <section className="gen-card" aria-labelledby="g-dados">
          <h2 id="g-dados" className="gen-h2">Paciente</h2>
          <label className="fld">
            <span><User size={14} strokeWidth={1.5} aria-hidden="true" />Nome</span>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex.: Maria Clara" autoComplete="off" autoCapitalize="words" maxLength={40} aria-invalid={nameError} />
            {nameError && <small className="err">Use só letras e espaços (até 40 caracteres).</small>}
            <small>Prefira o primeiro nome ou nome e sobrenome. Ele aparece no envelope e no convite.</small>
          </label>
          <div className="fld-row">
            <label className="fld">
              <span><CalendarDays size={14} strokeWidth={1.5} aria-hidden="true" />Data</span>
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </label>
            <label className="fld">
              <span><Clock size={14} strokeWidth={1.5} aria-hidden="true" />Horário</span>
              <input type="time" value={time} onChange={(e) => setTime(e.target.value)} step={300} />
            </label>
          </div>
          <small className="hint">Sem horário, o convite mostra o período do evento ({C.event.hours}) e convida a reservar.</small>
          <div className="fld-row fld-row-price">
            <label className="fld">
              <span>R$ Valor (opcional)</span>
              <input value={priceRaw} onChange={(e) => setPriceRaw(e.target.value)} inputMode="decimal" placeholder="Ex.: 890,00" autoComplete="off" aria-invalid={priceError} />
              {priceError && <small className="err">Digite só o valor, ex.: 890 ou 1.290,50.</small>}
            </label>
            <label className="fld">
              <span>Descrição do valor</span>
              <input value={offerRaw} onChange={(e) => setOfferRaw(e.target.value)} maxLength={80} placeholder={C.offerTitle} />
            </label>
          </div>
          <small className="hint">{price ? `O convite mostra "${cleanOffer(offerRaw) || C.offerTitle}: ${formatPrice(price)}". ` : ''}Uso individual: valor só em mensagem direta à paciente, nunca em post ou anúncio (CFO).</small>
          <label className="fld">
            <span><MessageCircle size={14} strokeWidth={1.5} aria-hidden="true" />WhatsApp da paciente (opcional)</span>
            <input value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel" placeholder="(19) 99999-9999" autoComplete="off" aria-invalid={!phoneOk} />
            {!phoneOk && <small className="err">Confira o número com DDD.</small>}
            <small>Com o número, o WhatsApp já abre na conversa dela. Sem ele, você escolhe o contato na hora.</small>
          </label>
        </section>

        <section className="gen-card" aria-labelledby="g-msg">
          <h2 id="g-msg" className="gen-h2">Mensagem</h2>
          <div className="gen-preview" aria-live="polite">
            <p className="gp-env">{nm ? `${nm}, você está convidada para uma experiência especial` : 'Você está convidada para uma experiência especial'}</p>
            <p className="gp-when">{personal.date ? dateLong(personal.date) : 'data do evento'} · {personal.time ? `às ${timeLabel(personal.time)}` : C.event.hours}{price ? ` · ${formatPrice(price)}` : ''}</p>
          </div>
          <label className="fld">
            <span>Texto enviado</span>
            <textarea value={message} readOnly rows={12} onFocus={(e) => e.currentTarget.select()} />
          </label>
          <details className="gen-tpl">
            <summary>Editar modelo da mensagem</summary>
            <textarea value={tpl} onChange={(e) => setTpl(e.target.value)} rows={4} />
            <small>Use {'{nome}'}, {'{dia}'}, {'{horario}'}, {'{condicao}'} e {'{link}'}. Fica salvo neste aparelho. O valor não vai na mensagem: aparece só dentro do convite.</small>
            <button type="button" className="lnk" onClick={() => setTpl(C.shareTemplate)}>Restaurar modelo padrão</button>
          </details>
          <div className="gen-actions">
            <button type="button" className="g-btn ghost" disabled={!nm} onClick={() => onPreview(personal)}><Eye size={16} strokeWidth={1.5} aria-hidden="true" />Ver prévia</button>
            <button type="button" className="g-btn ghost" disabled={!ready} onClick={async () => setFlash((await copyText(message)) ? 'Mensagem copiada' : 'Não foi possível copiar')}><Copy size={16} strokeWidth={1.5} aria-hidden="true" />Copiar texto</button>
            <a className={`g-btn solid${ready ? '' : ' off'}`} href={ready ? wa : undefined} aria-disabled={!ready} target="_blank" rel="noopener"
              onClick={(e) => { if (!ready) { e.preventDefault(); return; } record(); setFlash('Registrado no histórico'); }}>
              <MessageCircle size={17} strokeWidth={1.5} aria-hidden="true" /><b>Enviar pelo WhatsApp</b>
            </a>
            {hist.length > 0 && ready && <button type="button" className="lnk" onClick={next}>Limpar para a próxima paciente</button>}
          </div>
          {flash && <p className="flash" role="status"><Check size={14} aria-hidden="true" />{flash}</p>}
        </section>

        <section className="gen-card" aria-labelledby="g-link">
          <h2 id="g-link" className="gen-h2">Endereço do convite</h2>
          <label className="fld">
            <span><Link2 size={14} strokeWidth={1.5} aria-hidden="true" />Link público do convite</span>
            <input value={base} onChange={(e) => setBase(e.target.value)} inputMode="url" placeholder="https://seu-site.com.br/convite.html" autoComplete="off" spellCheck={false} aria-invalid={!!base.trim() && !baseOk} />
            <small>O endereço onde o arquivo do convite está publicado. Preencha uma vez; fica salvo neste aparelho.</small>
          </label>
          {link && (
            <div className="gen-out">
              <code>{link}</code>
              <button type="button" className="g-btn ghost sm" onClick={async () => setFlash((await copyText(link)) ? 'Link copiado' : 'Não foi possível copiar')}><Copy size={14} strokeWidth={1.5} aria-hidden="true" />Copiar link</button>
            </div>
          )}
        </section>

        {hist.length > 0 && (
          <section className="gen-card" aria-labelledby="g-hist">
            <h2 id="g-hist" className="gen-h2">Enviados neste aparelho</h2>
            <ul className="gen-hist">
              {hist.slice(0, 30).map((h) => (
                <li key={h.at}>
                  <span><b>{h.name}</b>{h.date ? ` · ${dateLong(h.date)}` : ''}{h.time ? `, ${timeLabel(h.time)}` : ''}{h.price ? ` · ${formatPrice(h.price)}` : ''}</span>
                  <button type="button" className="lnk" onClick={() => { setName(h.name); setDate(h.date || date); setTime(h.time); setPhone(h.phone ? h.phone.replace(/^55/, '') : ''); setPriceRaw(h.price ? formatPrice(h.price).replace(/[^\d,.]/g, '') : ''); if (h.offer) setOfferRaw(h.offer); document.querySelector('.gen')?.scrollTo({ top: 0, behavior: 'smooth' }); }}>Reabrir</button>
                </li>
              ))}
            </ul>
            <button type="button" className="lnk danger" onClick={() => setHist([])}>Apagar histórico</button>
          </section>
        )}
        <p className="gen-foot press">Dados de saúde e contato são sensíveis (LGPD): o link leva só o nome, a data e o horário. O histórico não sai deste aparelho.</p>
      </div>
    </div>
  );
}
