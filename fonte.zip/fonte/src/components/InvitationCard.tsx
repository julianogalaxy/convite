import { forwardRef, type ReactNode, type Ref } from 'react';

/** A carta: começa dentro do envelope (escala reduzida) e se expande até ocupar a tela,
 *  virando a própria página do convite, sem troca de tela. */
export const InvitationCard = forwardRef<HTMLDivElement, { children: ReactNode; scrollable: boolean; lightRef: Ref<HTMLDivElement> }>(
  function InvitationCard({ children, scrollable, lightRef }, ref) {
    return (
      <article className={`letter${scrollable ? ' is-scrollable' : ''}`} ref={ref} aria-label="Convite">
        <div className="letter-paper">{children}</div>
        {/* borda dourada do cartão e luz que percorre o papel enquanto ele sai do envelope */}
        <div className="card-edge" aria-hidden="true" />
        <div className="card-light" ref={lightRef} aria-hidden="true" />
      </article>
    );
  },
);
