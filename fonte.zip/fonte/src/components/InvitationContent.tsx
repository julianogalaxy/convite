import { useEffect, useMemo, useRef } from 'react';
import { CalendarDays, Clock, MapPin, MessageCircle, RotateCcw, Sparkles } from 'lucide-react';
import { INVITATION as C } from '../config/invitation';
import { formatPrice, type EventInfo } from '../config/personalization';
import { brtParts, DIAS, gcalStamp, MESES, useCountdown, useNotchedFrame, useScratch } from '../hooks/useInvitationHooks';
import wordmark from '../assets/wordmark_gold.webp';
import portrait from '../assets/portrait.webp';

const TOOTH_L = 'M838 107L615 5L488 218L742 717L898 472L615 5';
const TOOTH_R = 'M808 470L1090 5L1220 218L968 717L660 241L1090 5';

function Ornament() {
  return <div className="orn" aria-hidden="true"><span /><i /><span /></div>;
}

interface Props {
  guest: string;
  event: EventInfo;
  /** valor em centavos e descrição (convite individual gerado pela clínica) */
  price?: string;
  offer?: string;
  completed: boolean;
  reduced: boolean;
  onRestart: () => void;
}

/** Conteúdo do convite. Itens com data-reveal entram em sequência pela timeline. */
export function InvitationContent({ guest, event: E, price, offer, completed, reduced, onRestart }: Props) {
  const boxRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<SVGSVGElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const ovalRef = useRef<HTMLDivElement>(null);
  useNotchedFrame(boxRef, frameRef);
  const scratch = useScratch(canvasRef, ovalRef, completed, reduced);
  const cd = useCountdown(E.start, E.end, completed);

  useEffect(() => {
    const draw = () => scratch.drawCover();
    if (document.fonts?.ready) document.fonts.ready.then(draw); else draw();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const start = useMemo(() => new Date(E.start).getTime(), [E.start]);
  const end = useMemo(() => new Date(E.end).getTime(), [E.end]);
  const p = brtParts(start);
  const links = useMemo(() => {
    const wa = `https://wa.me/${C.whatsapp.number}?text=${encodeURIComponent(C.whatsapp.message(guest, p.d, MESES[p.mo].toLowerCase(), E.personalized && E.hours.startsWith('às') ? E.hours : ''))}`;
    const cal = 'https://calendar.google.com/calendar/render?action=TEMPLATE' +
      `&text=${encodeURIComponent(`${C.campaign} · ${C.clinic.name}`)}` +
      `&dates=${gcalStamp(start)}/${gcalStamp(end)}&ctz=America/Sao_Paulo` +
      `&details=${encodeURIComponent(`Atendimento com hora marcada. Reserve pelo WhatsApp ${C.whatsapp.display}: https://wa.me/${C.whatsapp.number}`)}` +
      `&location=${encodeURIComponent(C.clinic.fullAddress)}`;
    const map = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(C.clinic.fullAddress)}`;
    return { wa, cal, map };
  }, [guest, start, end, p.d, p.mo, E.personalized, E.hours]);

  return (
    <div className="sheet">
      <div className="frame-box" ref={boxRef}>
        <svg className="frame" ref={frameRef} aria-hidden="true" focusable="false">
          <path fill="none" stroke="url(#gFrame)" strokeWidth="1.3" />
          <path fill="none" stroke="#FFFFFF" strokeOpacity=".9" strokeWidth="1" />
          <path fill="none" stroke="#9C7535" strokeOpacity=".38" strokeWidth=".9" />
          <g fill="#FBF7F0" stroke="url(#gFrame)" strokeWidth="1.1" />
        </svg>

        <div className="content">
          {/* Monograma visível desde a carta dentro do envelope */}
          <header className="group brand">
            <svg className="mark" viewBox="466 -14 776 752" aria-hidden="true" focusable="false">
              <path d={TOOTH_L} /><path d={TOOTH_R} />
            </svg>
            <img className="wordmark" src={wordmark} width={380} height={68} alt={C.clinic.name} />
          </header>

          <section className="group hero" aria-labelledby="ttl">
            <div data-reveal><Ornament /></div>
            <p className="eyebrow" data-reveal>
              {guest ? <><span className="greet-name gold">{guest},</span><span className="caps gold-deep">{C.eyebrow}</span></> : <span className="caps gold-deep">{C.eyebrow}</span>}
            </p>
            <h1 className="title" id="ttl"><span className="gold">{C.campaign}</span></h1>
            <p className="edition" data-reveal><span className="caps gold-deep">{C.edition}</span></p>
            <p className="welcome press" data-reveal>{C.welcome}</p>
          </section>

          <section className="group experience" data-reveal>
            <Sparkles className="ico" size={18} strokeWidth={1.3} aria-hidden="true" />
            <h2 className="h2"><span className="gold">{C.experienceTitle}</span></h2>
            <p className="body press">{C.experienceText}</p>
          </section>

          <figure className="group pro" data-reveal>
            <div className={`oval${scratch.revealed ? ' revealed' : ''}`}>
              <div className="oval-ring" {...scratch.handlers}>
                <div className="oval-frame" ref={ovalRef}>
                  <img className="portrait" src={portrait} width={540} height={692} alt={`${C.professional.name}, sorrindo, com jaleco branco`} />
                  <canvas className="scratch" ref={canvasRef} role="button" tabIndex={completed && !scratch.revealed ? 0 : -1}
                    aria-label={scratch.revealed ? 'Foto revelada' : 'Raspe ou toque para revelar a foto'}
                    onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); scratch.autoReveal(); } }} />
                  <div className="foil-sheen" aria-hidden="true" />
                </div>
              </div>
            </div>
            <figcaption className="pro-cap">
              <span className="cap-hint caps gold-deep">{scratch.revealed ? ' ' : 'Raspe para conhecer quem vai cuidar de você'}</span>
              <span className="pro-name"><span className="gold">{C.professional.name}</span></span>
              <span className="caps gold-deep small">{C.professional.area}</span>
              <span className="press small-serif">{C.professional.specialty} <span className="nw">· {C.professional.registry}</span></span>
            </figcaption>
          </figure>

          <section className="group procedures">
            <div data-reveal><Ornament /></div>
            <h2 className="h2" data-reveal><span className="gold">{C.proceduresTitle}</span></h2>
            <ul className="proc-list">
              {C.procedures.map((it) => (
                <li key={it.title} data-reveal>
                  <span className="proc-title caps gold-deep">{it.title}</span>
                  <span className="proc-detail press">{it.detail}</span>
                </li>
              ))}
            </ul>
            <p className="note press" data-reveal>{C.proceduresNote}</p>
          </section>

          <section className="group when" aria-label="Data e horário" data-reveal>
            <div className="date">
              <span className="d-side"><b className="caps gold-deep">{DIAS[p.wd]}</b></span>
              <span className="d-day gold">{p.d}</span>
              <span className="d-side"><b className="caps gold-deep">{MESES[p.mo]}</b></span>
            </div>
            <p className="d-meta"><Clock size={13} strokeWidth={1.4} aria-hidden="true" /><b className="caps gold-deep">{p.y} · {E.hours}</b></p>
            {cd.status === 'future' && (
              <div className="countdown" role="timer" aria-live="off">
                <div><b className="gold">{cd.d}</b><small className="caps gold-deep">dias</small></div><i />
                <div><b className="gold">{cd.h}</b><small className="caps gold-deep">horas</small></div><i />
                <div><b className="gold">{cd.m}</b><small className="caps gold-deep">min</small></div>
              </div>
            )}
            {cd.status === 'today' && <p className="note press">É hoje.</p>}
            <p className="note press">{cd.status === 'past' ? 'Fale com a gente para conhecer a próxima data.' : E.agendaNote}</p>
          </section>

          {price && (
            <section className="group offer" data-reveal aria-label="Valor">
              <Ornament />
              <p className="caps gold-deep offer-title">{offer || C.offerTitle}</p>
              <p className="offer-price"><span className="gold">{formatPrice(price)}</span></p>
              <p className="note press">{C.offerNote}</p>
            </section>
          )}

          <section className="group act" data-reveal>
            <a className="cta" href={links.wa} target="_blank" rel="noopener"><MessageCircle size={17} strokeWidth={1.5} aria-hidden="true" /><b>{E.personalized && E.hours.startsWith('às') ? 'Confirmar pelo WhatsApp' : 'Agendar pelo WhatsApp'}</b></a>
            <p className="cta-sub press">{C.whatsapp.display}</p>
            <div className="links">
              <a href={links.cal} target="_blank" rel="noopener"><CalendarDays size={15} strokeWidth={1.4} aria-hidden="true" /><b className="caps gold-deep">Salvar na agenda</b></a>
              <a href={links.map} target="_blank" rel="noopener"><MapPin size={15} strokeWidth={1.4} aria-hidden="true" /><b className="caps gold-deep">Como chegar</b></a>
            </div>
          </section>

          <footer className="group foot" data-reveal>
            <Ornament />
            <address className="place press">
              <b className="gold-deep">{C.clinic.name}</b>
              <span>{C.clinic.street}</span><span>{C.clinic.district}</span><span>{C.clinic.zip}</span>
            </address>
            <p className="ig caps gold-deep">{C.professional.instagram}</p>
            <p className="legal press">
              {C.legal}{C.clinic.croRegistration ? ` Clínica inscrita no CRO-SP sob nº ${C.clinic.croRegistration}.` : ''} {C.proceduresNote}
            </p>
            <button className="replay" type="button" onClick={onRestart}>
              <RotateCcw size={14} strokeWidth={1.4} aria-hidden="true" /><b className="caps">Ver a abertura de novo</b>
            </button>
          </footer>
        </div>
      </div>
    </div>
  );
}
