import { gsap } from 'gsap';

/* =========================================================================
   Configuração central de tempos, curvas, escalas e movimentos.
   Ajuste aqui sem tocar nos componentes.
   ========================================================================= */
export const MOTION = {
  /** duração total da abertura (s). A timeline é reescalada para caber nela (4 a 9 s). */
  totalDuration: 7.6,
  /** envelope fechado: leve inclinação 3D */
  rest: { scale: 1, yPercent: 0, rotationX: 8, rotationY: -5 },
  /** durante a abertura o envelope recua e desce para dar espaço à aba e à carta */
  open: { scale: 0.9, yPercent: 8 },
  idle: { y: 5, rotationY: 1.6, duration: 3.4 },
  /** toque: o selo inteiro afunda sob o dedo e volta devagar (sem trincar) */
  press: { scale: 0.9, down: 0.3, up: 0.45 },
  crack: { at: 0.62, duration: 0.22, topTurn: 2.6, baseTurn: -2.2, gap: 1.6 },
  /** a aba descola um pouco antes de girar, como papel colado pela cera */
  unstick: { angle: 7, duration: 0.45 },
  flap: { at: 0.95, duration: 1.9, ease: 'power2.inOut' },
  sides: { flex: 10, settle: 3.5, bottomFlex: 7 },
  /** cartão dentro do envelope, em proporção do envelope */
  card: { width: 0.9, height: 0.93, top: 0.035, rise: 0.46 },
  letter: { duration: 2.25, ease: 'power1.inOut', tilt: -0.7 },
  expand: { hold: 0.18, duration: 1.75, ease: 'power3.inOut', drop: 0.85, sideOpen: 24, bottomOpen: 16 },
  reveal: { duration: 1.2, stagger: 0.14, y: 18, ease: 'power2.out' },
  /** ordem de pintura das camadas (z-index). Determinística em Safari e Chrome. */
  layer: { flapOpen: 1, body: 2, contactShadow: 3, letter: 4, sides: 5, bottomShadow: 6, bottom: 7, flapShadow: 8, sealBase: 9, flapClosed: 10 },
} as const;

export type Phase = 'idle' | 'seal-interaction' | 'opening' | 'letter-emerging' | 'revealing' | 'completed';

export interface SceneRefs {
  rig: HTMLElement;
  body: HTMLElement;
  letter: HTMLElement;
  contactShadow: HTMLElement;
  sideLeft: HTMLElement;
  sideRight: HTMLElement;
  bottom: HTMLElement;
  bottomShadow: HTMLElement;
  flap: HTMLElement;
  flapShade: HTMLElement;
  flapShadow: HTMLElement;
  seal: HTMLElement;
  sealGlow: HTMLElement;
  sealBase: HTMLElement;
  sealBaseHalf: HTMLElement;
  flapBackShade: HTMLElement;
  cardLight: HTMLElement;
  closedText: HTMLElement;
  revealItems: () => HTMLElement[];
}

/** Faces da aba. A opacidade é aplicada nelas (folhas), nunca no contêiner 3D,
 *  para não achatar o preserve-3d no Safari/Chrome. */
const flapFaces = (r: SceneRefs) => Array.from(r.flap.querySelectorAll<HTMLElement>('.flap-face'));

/** Distância do topo do elemento até o topo da carta, sem efeito das transformações. */
function offsetWithin(el: HTMLElement, root: HTMLElement): number {
  let y = 0;
  let n: HTMLElement | null = el;
  while (n && n !== root) { y += n.offsetTop; n = n.offsetParent as HTMLElement | null; }
  return y;
}

/** Itens visíveis na primeira tela entram pela timeline; o restante entra ao rolar. */
export function splitRevealItems(r: SceneRefs): { firstScreen: HTMLElement[]; onScroll: HTMLElement[] } {
  const limit = r.letter.clientHeight * 0.9;
  const all = r.revealItems();
  return {
    firstScreen: all.filter((el) => offsetWithin(el, r.letter) < limit),
    onScroll: all.filter((el) => offsetWithin(el, r.letter) >= limit),
  };
}

/** Geometria medida a partir do layout (offsets não sofrem efeito das transformações). */
export interface Geometry {
  W: number; H: number;
  /** escala da carta dentro do envelope */
  s: number;
  /** topo do cartão dentro do envelope (px, coordenadas da cena) */
  top: number;
  cw: number;
  /** altura visível do cartão */
  ch: number;
  /** recorte inferior da carta (px não escalados) para ela ter o formato de cartão */
  clip: number;
  /** quanto o cartão sobe ao sair do envelope */
  rise: number;
}

export function measure(r: SceneRefs): Geometry {
  const C = MOTION.card;
  const W = r.rig.clientWidth, H = r.rig.clientHeight;
  const LW = r.letter.offsetWidth || W;
  const ey = r.body.offsetTop, ew = r.body.offsetWidth, eh = r.body.offsetHeight;
  const cw = ew * C.width;
  const s = cw / LW;
  const ch = Math.min(eh * C.height, H * s);
  return { W, H, s, top: ey + eh * C.top, cw, ch, clip: Math.max(0, H - ch / s), rise: ch * C.rise };
}

/** Recorte inferior da carta. Aplicado direto no estilo (com prefixo para Safari antigo):
 *  interpolar clip-path pela engine não é confiável quando o navegador normaliza o valor. */
function setClip(el: HTMLElement, bottom: number): void {
  const v = bottom > 0.5 ? `inset(0px 0px ${bottom.toFixed(1)}px 0px)` : 'none';
  el.style.clipPath = v;
  el.style.setProperty('-webkit-clip-path', v);
}

/** Estado inicial (envelope fechado), também usado para reiniciar. */
export function setClosedState(r: SceneRefs, g: Geometry): void {
  const L = MOTION.layer;
  gsap.set(r.rig, { ...MOTION.rest, transformOrigin: '50% 50%', y: 0, clearProps: 'opacity' });
  gsap.set(r.body, { zIndex: L.body, y: 0, opacity: 1 });
  gsap.set(r.letter, { zIndex: L.letter, transformOrigin: '50% 0%', x: 0, y: g.top, scale: g.s, rotation: 0, opacity: 1 });
  setClip(r.letter, g.clip);
  gsap.set(r.contactShadow, { zIndex: L.contactShadow, left: (g.W - g.cw) / 2, top: g.top, width: g.cw, height: g.ch, y: 0, opacity: 0 });
  gsap.set(r.sideLeft, { zIndex: L.sides, y: 0, rotationY: 0, transformOrigin: '0% 50%', opacity: 1 });
  gsap.set(r.sideRight, { zIndex: L.sides, y: 0, rotationY: 0, transformOrigin: '100% 50%', opacity: 1 });
  gsap.set(r.bottomShadow, { zIndex: L.bottomShadow, y: 0, opacity: 1 });
  gsap.set(r.bottom, { zIndex: L.bottom, y: 0, rotationX: 0, transformOrigin: '50% 100%', opacity: 1 });
  gsap.set(r.flapShadow, { zIndex: L.flapShadow, y: 0, opacity: 1 });
  gsap.set(r.flap, { zIndex: L.flapClosed, y: 0, rotationX: 0, transformOrigin: '50% 0%' });
  gsap.set(flapFaces(r), { opacity: 1 });
  gsap.set(r.flapShade, { opacity: 0 });
  gsap.set(r.seal, { scale: 1, rotation: 0, x: 0, y: 0, z: 1, opacity: 1 });
  gsap.set(r.sealBase, { zIndex: L.sealBase, y: 0, opacity: 1 });
  gsap.set(r.sealBaseHalf, { scale: 1, rotation: 0, x: 0, y: 0, opacity: 1 });
  gsap.set(r.flapBackShade, { opacity: 0.5 });
  gsap.set(r.cardLight, { yPercent: -60, opacity: 0 });
  gsap.set(r.sealGlow, { opacity: 0.85 });
  gsap.set(r.closedText, { opacity: 1, y: 0 });
  gsap.set(r.revealItems(), { opacity: 0, y: MOTION.reveal.y });
}

/** Respiração do envelope fechado e brilho do selo. */
export function createIdle(r: SceneRefs): gsap.core.Timeline {
  const tl = gsap.timeline({ repeat: -1, yoyo: true, defaults: { ease: 'sine.inOut' } });
  tl.to(r.rig, { y: -MOTION.idle.y, rotationY: MOTION.rest.rotationY + MOTION.idle.rotationY, duration: MOTION.idle.duration }, 0);
  tl.to(r.sealGlow, { opacity: 0.35, duration: MOTION.idle.duration * 0.6 }, 0);
  return tl;
}

/**
 * Timeline única da abertura. Todos os elementos participam da mesma cena;
 * nenhuma troca de página. As fases são anunciadas por callbacks para a máquina de estados.
 */
/** Instante (0..1) em que power2.inOut atinge a fração e. */
const inOut2At = (e: number) => (e < 0.5 ? Math.sqrt(e / 2) : 1 - Math.sqrt((1 - e) / 2));

export function createOpeningTimeline(r: SceneRefs, g: Geometry, onPhase: (p: Phase) => void): gsap.core.Timeline {
  const M = MOTION;
  const L = M.layer;
  const tl = gsap.timeline({ paused: true, defaults: { ease: 'power2.inOut' } });
  const envelope = [r.body, r.sideLeft, r.sideRight, r.bottom, r.bottomShadow, r.flapShadow, r.sealBase];
  const halves = [r.seal, r.sealBaseHalf];
  const clip = { b: g.clip };

  // ETAPA 2: interação. O selo afunda sob o dedo e volta devagar
  const P = M.press, K = M.crack;
  tl.addLabel('press', 0)
    .call(() => onPhase('seal-interaction'), [], 'press')
    .to(halves, { scale: P.scale, duration: P.down, ease: 'power2.out' }, 'press')
    .to(halves, { scale: 0.97, duration: P.up, ease: 'power1.out' }, `press+=${P.down}`)
    .to(r.sealGlow, { opacity: 0, duration: 0.7, ease: 'power1.out' }, 'press')
    .to(r.closedText, { opacity: 0, y: 8, duration: 0.6, ease: 'power1.in' }, 'press')
    .addLabel('crack', K.at)
    // a aba descola levemente, levando o selo inteiro com ela
    .to(r.flap, { rotationX: M.unstick.angle, duration: M.unstick.duration, ease: 'power2.out' }, 'crack+=0.04')
    .to(r.flapShadow, { opacity: 0.6, duration: M.unstick.duration, ease: 'power1.out' }, 'crack+=0.04');

  // o envelope endireita, recua e desce um pouco para dar espaço à aba e à carta
  tl.to(r.rig, { ...M.open, y: 0, rotationX: 0, rotationY: 0, duration: 2.1, ease: 'power3.inOut' }, 'press+=0.45');

  // ETAPA 3: abertura. A aba gira no eixo horizontal, com luz mudando nas duas faces
  const F = M.flap;
  const at90 = F.duration * inOut2At((90 - M.unstick.angle) / (180 - M.unstick.angle));
  tl.addLabel('open', F.at)
    .call(() => onPhase('opening'), [], 'open')
    .to(r.flap, { rotationX: 180, duration: F.duration, ease: F.ease }, 'open')
    // em 90° a aba está de perfil: troca de camada e passa a ficar atrás da carta
    .set(r.flap, { zIndex: L.flapOpen }, `open+=${at90}`)
    .to(r.flapShade, { opacity: 0.32, duration: at90, ease: 'power1.in' }, 'open')
    .to(r.flapBackShade, { opacity: 0, duration: F.duration - at90, ease: 'power1.out' }, `open+=${at90}`)
    .to(r.flapShadow, { opacity: 0, duration: 0.6, ease: 'power1.out' }, 'open')
    .to(r.sideLeft, { rotationY: -M.sides.flex, duration: 1.2, ease: 'sine.inOut' }, `open+=${F.duration * 0.55}`)
    .to(r.sideRight, { rotationY: M.sides.flex, duration: 1.2, ease: 'sine.inOut' }, `open+=${F.duration * 0.6}`)
    .to(r.bottom, { rotationX: -M.sides.bottomFlex, duration: 1.2, ease: 'sine.inOut' }, `open+=${F.duration * 0.65}`);

  // ETAPA 4: a carta desliza para fora, com atrito no início, leve inclinação e luz percorrendo o papel
  const T = M.letter;
  tl.addLabel('emerge', `open+=${F.duration - 0.1}`)
    .call(() => onPhase('letter-emerging'), [], 'emerge')
    .fromTo(r.letter, { rotation: 0 }, { y: g.top - g.rise, rotation: T.tilt, duration: T.duration, ease: T.ease }, 'emerge')
    .to(r.letter, { rotation: 0, duration: 0.7, ease: 'sine.inOut' }, `emerge+=${T.duration - 0.35}`)
    .to(r.contactShadow, { y: -g.rise, opacity: 1, duration: T.duration, ease: T.ease }, 'emerge')
    .to(r.cardLight, { yPercent: 40, duration: T.duration + 0.6, ease: 'sine.inOut' }, 'emerge')
    .to(r.cardLight, { opacity: 1, duration: T.duration * 0.5, ease: 'sine.out' }, 'emerge')
    .to(r.sideLeft, { rotationY: -M.sides.settle, duration: 1.1, ease: 'sine.inOut' }, `emerge+=${T.duration * 0.55}`)
    .to(r.sideRight, { rotationY: M.sides.settle, duration: 1.1, ease: 'sine.inOut' }, `emerge+=${T.duration * 0.6}`)
    .to(r.bottom, { rotationX: -M.sides.settle * 0.6, duration: 1.1, ease: 'sine.inOut' }, `emerge+=${T.duration * 0.62}`);

  // ETAPA 5: breve pausa; a carta se expande e vira a página; o envelope desliza para baixo e sai de cena
  const X = M.expand;
  tl.addLabel('expand', `emerge+=${T.duration + X.hold}`)
    .call(() => onPhase('revealing'), [], 'expand')
    .to(r.rig, { scale: 1, yPercent: 0, duration: X.duration, ease: X.ease }, 'expand')
    .to(r.letter, { y: 0, scale: 1, rotation: 0, duration: X.duration, ease: X.ease }, 'expand')
    .fromTo(clip, { b: g.clip }, { b: 0, duration: X.duration, ease: X.ease, onUpdate: () => setClip(r.letter, clip.b) }, 'expand')
    .to(r.cardLight, { opacity: 0, duration: X.duration * 0.6, ease: 'power1.in' }, 'expand')
    .to(r.contactShadow, { opacity: 0, duration: 0.6 }, 'expand')
    .to(r.sideLeft, { rotationY: -X.sideOpen, duration: X.duration * 0.8, ease: 'power2.in' }, 'expand')
    .to(r.sideRight, { rotationY: X.sideOpen, duration: X.duration * 0.8, ease: 'power2.in' }, 'expand+=0.04')
    .to(r.bottom, { rotationX: -X.bottomOpen, duration: X.duration * 0.8, ease: 'power2.in' }, 'expand+=0.08')
    // o envelope desliza para baixo e sai de cena, opaco, como papel de verdade
    .to([...envelope, r.flap], { y: g.H * X.drop, duration: X.duration * 0.9, ease: 'power2.in' }, 'expand')
    .to([...envelope, ...flapFaces(r)], { opacity: 0, duration: X.duration * 0.25, ease: 'none' }, `expand+=${X.duration * 0.65}`);

  // tipografia em sequência (a primeira tela entra aqui; o restante, ao rolar)
  tl.addLabel('reveal', `expand+=${X.duration - 0.35}`)
    .to(splitRevealItems(r).firstScreen, { opacity: 1, y: 0, duration: M.reveal.duration, stagger: M.reveal.stagger, ease: M.reveal.ease }, 'reveal')
    .call(() => onPhase('completed'), [], `reveal+=${M.reveal.duration * 0.5}`);

  // reescala para a duração total configurada (mantém as proporções entre etapas)
  const natural = tl.duration();
  const target = Math.min(9, Math.max(4, MOTION.totalDuration));
  tl.timeScale(natural / target);
  return tl;
}

/** Movimento reduzido: vai direto ao estado final, com um fade curto. */
export function createReducedTimeline(r: SceneRefs, _g: Geometry, onPhase: (p: Phase) => void): gsap.core.Timeline {
  const tl = gsap.timeline({ paused: true });
  tl.call(() => onPhase('seal-interaction'))
    .set(r.rig, { scale: 1, yPercent: 0, y: 0, rotationX: 0, rotationY: 0 })
    .set(r.letter, { y: 0, scale: 1 })
    .call(() => setClip(r.letter, 0))
    .set([r.sideLeft, r.sideRight, r.bottom, r.bottomShadow, ...flapFaces(r), r.seal, r.sealBase, r.flapShadow, r.body, r.contactShadow, r.closedText, r.cardLight], { opacity: 0 })
    .fromTo(r.letter, { opacity: 0 }, { opacity: 1, duration: 0.4 })
    .set(r.revealItems(), { opacity: 1, y: 0 })
    .call(() => onPhase('completed'));
  return tl;
}
