import type { Phase } from './AnimationTimeline';

/**
 * Máquina de estados simples da experiência.
 * idle → seal-interaction → opening → letter-emerging → revealing → completed
 * Só 'idle' aceita o toque de abertura; 'completed' aceita reiniciar.
 */
export type MachineEvent =
  | { type: 'TAP' }
  | { type: 'PHASE'; phase: Phase }
  | { type: 'RESTART' };

const ORDER: Phase[] = ['idle', 'seal-interaction', 'opening', 'letter-emerging', 'revealing', 'completed'];

export function machine(state: Phase, event: MachineEvent): Phase {
  switch (event.type) {
    case 'TAP':
      return state === 'idle' ? 'seal-interaction' : state;
    case 'PHASE':
      // só avança; nunca volta no meio da sequência
      return ORDER.indexOf(event.phase) > ORDER.indexOf(state) ? event.phase : state;
    case 'RESTART':
      return state === 'completed' ? 'idle' : state;
    default:
      return state;
  }
}

export const isAnimating = (p: Phase) => p !== 'idle' && p !== 'completed';
