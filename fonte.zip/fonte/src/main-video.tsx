import { StrictMode, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { VideoIntro } from './components/VideoIntro';
import { readPersonal } from './config/personalization';
import './styles.css';
import { installViewport } from './viewport';

installViewport();
import cotton from './assets/cotton.webp';
import envPaper from './assets/env-paper.webp';
import cardPaper from './assets/card-paper.webp';

const root = document.documentElement.style;
root.setProperty('--paper-grain', `url(${cotton})`);
root.setProperty('--env-paper', `url(${envPaper})`);
root.setProperty('--card-paper', `url(${cardPaper})`);

function AppVideo() {
  const [personal] = useState(readPersonal);
  return <VideoIntro personal={personal} />;
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AppVideo />
  </StrictMode>,
);
