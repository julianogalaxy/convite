declare module '*.webp' { const src: string; export default src; }
declare module '*.woff' { const src: string; export default src; }
declare module '*.css';
declare module '*.mp4' { const src: string; export default src; }
