import { useCallback, useEffect, useRef, useState, type RefObject } from 'react';

const BRT = -3 * 3600e3;
export const DIAS = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
export const MESES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
const pad = (n: number) => (n < 10 ? '0' : '') + n;

export function brtParts(ts: number) {
  const d = new Date(ts + BRT);
  return { y: d.getUTCFullYear(), mo: d.getUTCMonth(), d: d.getUTCDate(), wd: d.getUTCDay(), h: d.getUTCHours(), mi: d.getUTCMinutes() };
}
export function gcalStamp(ts: number) {
  const p = brtParts(ts);
  return `${p.y}${pad(p.mo + 1)}${pad(p.d)}T${pad(p.h)}${pad(p.mi)}00`;
}

/** Nome do convidado vindo do link (#maria-clara ou ?para=Maria). */
export function readGuestName(): string {
  let raw = '';
  try { raw = decodeURIComponent((location.hash || '').slice(1)); } catch { /* ignora */ }
  if (!raw) { try { raw = new URLSearchParams(location.search).get('para') || ''; } catch { /* ignora */ } }
  raw = raw.replace(/[-_+.]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (raw.length < 2 || raw.length > 40 || !/^[A-Za-zÀ-ÖØ-öø-ÿ' ]+$/.test(raw)) return '';
  const small: Record<string, 1> = { da: 1, de: 1, di: 1, do: 1, das: 1, dos: 1, e: 1 };
  return raw.toLowerCase().split(' ').map((w, i) => (i > 0 && small[w] ? w : w.charAt(0).toUpperCase() + w.slice(1))).join(' ');
}

export function useCountdown(startIso: string, endIso: string, active: boolean) {
  const start = new Date(startIso).getTime();
  const end = new Date(endIso).getTime();
  const calc = useCallback(() => {
    const now = Date.now();
    if (now > end) return { status: 'past' as const, d: '00', h: '00', m: '00' };
    if (now >= start) return { status: 'today' as const, d: '00', h: '00', m: '00' };
    const m = Math.floor((start - now) / 60000);
    return { status: 'future' as const, d: pad(Math.floor(m / 1440)), h: pad(Math.floor((m % 1440) / 60)), m: pad(m % 60) };
  }, [start, end]);
  const [val, setVal] = useState(calc);
  useEffect(() => {
    if (!active) return;
    setVal(calc());
    const t = window.setInterval(() => setVal(calc()), 15000);
    return () => window.clearInterval(t);
  }, [active, calc]);
  return val;
}

/** Moldura com cantos chanfrados, redesenhada ao mudar o tamanho do conteúdo. */
export function useNotchedFrame(box: RefObject<HTMLElement | null>, svg: RefObject<SVGSVGElement | null>) {
  useEffect(() => {
    const el = box.current, s = svg.current;
    if (!el || !s) return;
    const notched = (x0: number, y0: number, x1: number, y1: number, r: number) =>
      `M${x0 + r},${y0} H${x1 - r} A${r},${r} 0 0 0 ${x1},${y0 + r} V${y1 - r} A${r},${r} 0 0 0 ${x1 - r},${y1} H${x0 + r} A${r},${r} 0 0 0 ${x0},${y1 - r} V${y0 + r} A${r},${r} 0 0 0 ${x0 + r},${y0} Z`;
    const draw = () => {
      const w = el.clientWidth, h = el.clientHeight;
      if (!w || !h) return;
      s.setAttribute('viewBox', `0 0 ${w} ${h}`);
      const [o, hi, inn, gems] = Array.from(s.children) as SVGElement[];
      o.setAttribute('d', notched(0.5, 0.5, w - 0.5, h - 0.5, 18));
      hi.setAttribute('d', notched(8, 8, w - 6, h - 6, 13));
      inn.setAttribute('d', notched(7, 7, w - 7, h - 7, 13));
      const q = 3.8;
      gems.innerHTML = [[0.5, 0.5], [w - 0.5, 0.5], [w - 0.5, h - 0.5], [0.5, h - 0.5]]
        .map(([x, y]) => `<path d="M${x},${y - q} L${x + q},${y} L${x},${y + q} L${x - q},${y} Z"/>`).join('');
    };
    draw();
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(draw) : null;
    ro?.observe(el);
    window.addEventListener('resize', draw);
    return () => { ro?.disconnect(); window.removeEventListener('resize', draw); };
  }, [box, svg]);
}

/** Raspadinha dourada sobre a foto (cobertura medida por grade, sem leitura de pixels). */
export function useScratch(canvasRef: RefObject<HTMLCanvasElement | null>, frameRef: RefObject<HTMLDivElement | null>, enabled: boolean, reduced: boolean) {
  const [revealed, setRevealed] = useState(false);
  const st = useRef({ ctx: null as CanvasRenderingContext2D | null, w: 0, h: 0, cells: [] as number[], total: 0, hit: 0, active: false, last: { x: 0, y: 0 }, moved: 0, auto: false, done: false });
  const COLS = 14, ROWS = 18;

  const drawCover = useCallback(() => {
    const cv = canvasRef.current, fr = frameRef.current;
    if (!cv || !fr) return;
    const w = fr.clientWidth, h = fr.clientHeight;
    if (!w || !h) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
    const c = cv.getContext('2d');
    if (!c) return;
    const s = st.current;
    Object.assign(s, { ctx: c, w, h, hit: 0, total: 0, cells: [], done: false, auto: false, active: false });
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.globalCompositeOperation = 'source-over';
    const g = c.createLinearGradient(0, 0, w * 0.35, h);
    [[0, '#A9823A'], [0.22, '#E3C67E'], [0.42, '#F5E6BA'], [0.58, '#CDA757'], [0.8, '#E8CF8F'], [1, '#9C7633']].forEach(([o, col]) => g.addColorStop(o as number, col as string));
    c.fillStyle = g; c.fillRect(0, 0, w, h);
    for (let i = 0; i < 450; i++) { c.fillStyle = Math.random() < 0.5 ? 'rgba(255,248,225,.14)' : 'rgba(90,60,15,.08)'; c.fillRect(Math.random() * w, Math.random() * h, 1, 1); }
    const lg = c.createLinearGradient(0, h * 0.1, w, h * 0.6);
    lg.addColorStop(0, 'rgba(255,255,255,0)'); lg.addColorStop(0.5, 'rgba(255,250,235,.3)'); lg.addColorStop(1, 'rgba(255,255,255,0)');
    c.fillStyle = lg; c.fillRect(0, 0, w, h);
    c.strokeStyle = 'rgba(255,248,226,.6)'; c.lineWidth = 1; c.beginPath(); c.ellipse(w / 2, h / 2, w / 2 - 9, h / 2 - 9, 0, 0, Math.PI * 2); c.stroke();
    const spaced = (t: string, y: number, color: string) => {
      c.font = '400 13px "Josefin Sans", Futura, "Century Gothic", sans-serif';
      const ws = t.split('').map((ch) => c.measureText(ch).width);
      let x = w / 2 - (ws.reduce((a, b) => a + b, 0) + 5.2 * (t.length - 1)) / 2;
      c.textBaseline = 'middle'; c.fillStyle = color;
      t.split('').forEach((ch, k) => { c.fillText(ch, x, y); x += ws[k] + 5.2; });
    };
    spaced('RASPE', h * 0.5 + 1, 'rgba(110,78,24,.45)'); spaced('AQUI', h * 0.5 + 22, 'rgba(110,78,24,.45)');
    spaced('RASPE', h * 0.5, 'rgba(255,251,238,.97)'); spaced('AQUI', h * 0.5 + 21, 'rgba(255,251,238,.97)');
    c.globalCompositeOperation = 'destination-out';
    for (let r = 0; r < ROWS; r++) for (let q = 0; q < COLS; q++) {
      const ex = ((q + 0.5) * w / COLS - w / 2) / (w / 2), ey = ((r + 0.5) * h / ROWS - h / 2) / (h / 2);
      const inside = ex * ex + ey * ey <= 0.8;
      s.cells.push(inside ? 0 : -1); if (inside) s.total++;
    }
    setRevealed(false);
  }, [canvasRef, frameRef]);

  const stroke = (a: { x: number; y: number }, b: { x: number; y: number }, r: number) => {
    const s = st.current, c = s.ctx;
    if (!c) return 0;
    c.lineWidth = r * 2; c.lineCap = 'round'; c.lineJoin = 'round';
    c.beginPath(); c.moveTo(a.x, a.y); c.lineTo(b.x + 0.01, b.y); c.stroke();
    const dx = b.x - a.x, dy = b.y - a.y, dist = Math.hypot(dx, dy), steps = Math.max(1, Math.ceil(dist / (r * 0.5)));
    const cw = s.w / COLS, ch = s.h / ROWS;
    for (let i = 0; i <= steps; i++) {
      const x = a.x + dx * i / steps, y = a.y + dy * i / steps;
      for (let rr = Math.max(0, Math.floor((y - r) / ch)); rr <= Math.min(ROWS - 1, Math.floor((y + r) / ch)); rr++)
        for (let qq = Math.max(0, Math.floor((x - r) / cw)); qq <= Math.min(COLS - 1, Math.floor((x + r) / cw)); qq++) {
          const k = rr * COLS + qq;
          if (s.cells[k] !== 0) continue;
          const cx = (qq + 0.5) * cw, cy = (rr + 0.5) * ch;
          if ((cx - x) ** 2 + (cy - y) ** 2 <= r * r) { s.cells[k] = 1; s.hit++; }
        }
    }
    return dist;
  };
  const brush = () => Math.max(18, st.current.w * 0.13);
  const reveal = () => { const s = st.current; if (s.done) return; s.done = true; setRevealed(true); };
  const autoReveal = () => {
    const s = st.current;
    if (s.done || s.auto) return;
    s.auto = true;
    if (reduced) { reveal(); return; }
    const t0 = performance.now(), r = brush() * 1.25;
    let prev: { x: number; y: number } | null = null;
    const frame = (now: number) => {
      const t = Math.min(1, (now - t0) / 950), zig = Math.abs(((t * 4.5) % 2) - 1);
      const p = { x: s.w * (0.12 + 0.76 * zig), y: s.h * (0.08 + 0.84 * t) };
      if (prev) stroke(prev, p, r);
      prev = p;
      if (t < 1) requestAnimationFrame(frame); else reveal();
    };
    requestAnimationFrame(frame);
  };
  const pos = (e: React.PointerEvent) => {
    const cv = canvasRef.current!, r = cv.getBoundingClientRect(), s = st.current;
    return { x: (e.clientX - r.left) * s.w / r.width, y: (e.clientY - r.top) * s.h / r.height };
  };
  const handlers = {
    onPointerDown: (e: React.PointerEvent<HTMLDivElement>) => {
      const s = st.current;
      if (!enabled || s.done || s.auto) return;
      e.preventDefault();
      try { e.currentTarget.setPointerCapture(e.pointerId); } catch { /* ignora */ }
      s.active = true; s.moved = 0; s.last = pos(e); stroke(s.last, s.last, brush());
    },
    onPointerMove: (e: React.PointerEvent<HTMLDivElement>) => {
      const s = st.current;
      if (!s.active || s.done) return;
      const p = pos(e); s.moved += stroke(s.last, p, brush()); s.last = p;
      if (s.total && s.hit / s.total >= 0.5) { s.active = false; reveal(); }
    },
    onPointerUp: () => {
      const s = st.current;
      if (!s.active) return;
      s.active = false;
      if (s.moved < 8) autoReveal(); else if (s.total && s.hit / s.total >= 0.38) reveal();
    },
  };
  return { revealed, drawCover, autoReveal, handlers };
}
