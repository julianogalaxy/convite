# Convite digital Botox Day · versão 2 (experiência em cena única)

Envelope 3D que abre com toque no selo, carta que sai do envelope e se expande até virar a página do convite, sem troca de tela.

Stack: React + TypeScript + Vite + GSAP (timeline) + SVG + Lucide React. Animação 100% em CSS 3D (perspective, preserve-3d, rotateX/rotateY, transform-origin, backface-visibility, clip-path), sem vídeo nem sequência de imagens.

## Rodar

```bash
npm install
npm run dev          # desenvolvimento
npm run build        # gera dist/index.html em arquivo único (vite-plugin-singlefile)
npm run build:single # alternativa com esbuild puro: dist/convite-v2-standalone.html
```

## Onde editar

| O que | Arquivo |
|---|---|
| Textos, data, procedimentos, endereço, WhatsApp | `src/config/invitation.ts` |
| Duração total (4 a 6 s), curvas, escalas, ordem das camadas | `src/animation/AnimationTimeline.ts` (objeto `MOTION`) |
| Fases da experiência | `src/animation/stateMachine.ts` |
| Tamanho e proporção do envelope | `src/styles.css` (variáveis `--ew`, `--eh`, `--fh`) |

## Convite personalizado por paciente

Abra `gerador-convites.html` (ou o convite com `#gerador` no fim do link). Preencha nome, data, horário e, se quiser, o WhatsApp da paciente; o gerador monta o link e a mensagem e abre o WhatsApp já com o texto.

Formato do link: `https://seu-endereco/convite.html#n=Maria%20Clara&d=2026-12-12&h=14:30`
(também aceita `?para=Maria&data=2026-12-12&hora=14:30` e `#Maria`). Sem data e horário, o convite mostra o evento geral.

O convite precisa estar publicado num endereço público (site da clínica, Netlify, GitHub Pages) para os links funcionarem no celular da paciente.

## Estrutura

```
src/
  animation/AnimationTimeline.ts   timeline GSAP, geometria, tempos e curvas centralizados
  animation/stateMachine.ts        idle > seal-interaction > opening > letter-emerging > revealing > completed
  components/EnvelopeScene.tsx     cena única, estado e orquestração
  components/EnvelopeBody.tsx      fundo com forro, abas laterais, aba inferior, sombras
  components/EnvelopeFlap.tsx      aba superior articulada (face externa, forro, selo)
  components/WaxSeal.tsx           selo de cera dourada em SVG
  components/InvitationCard.tsx    a carta (vira a página ao final)
  components/InvitationContent.tsx conteúdo do convite
  hooks/useInvitationHooks.ts      contagem regressiva, moldura, raspadinha da foto
qa/
  full.cjs     validação: viewports, fases, toques repetidos, reinício, movimento reduzido, raspadinha, desempenho
  stages.cjs   capturas de cada etapa da abertura (abra com ?qa para expor a timeline)
```

Validação: `npm i -D playwright && npx playwright install chromium && npm run qa`.

## Decisões técnicas

- Ordem de pintura por `z-index` trocado pela timeline (a aba passa para trás da carta exatamente a 90°). A ordenação automática de planos 3D difere entre Safari e Chrome; assim o resultado é idêntico nos dois.
- A opacidade nunca é aplicada a um contêiner com `preserve-3d` (isso achata o 3D no Safari); só às faces.
- A carta tem o tamanho final da página. Dentro do envelope ela é escalada e recortada no formato de cartão; na expansão, escala e recorte voltam a zero e ela vira a própria página rolável.
- Com "reduzir movimento" ativo no sistema, a abertura (disparada pelo toque) continua; só os movimentos automáticos em loop são desligados. Versão estática: `?semanimacao` no link.
