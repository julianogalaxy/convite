// Captura determinística das etapas da abertura (pausa a timeline e busca cada instante).
const { chromium, devices } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '../dist/convite-v2-standalone.html') + '?qa';
const vp = process.argv[2] || '390x844';
const [w, h] = vp.split('x').map(Number);
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 2, isMobile: w < 900, hasTouch: w < 900 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') errors.push(m.type() + ': ' + m.text()); });
  await page.goto(FILE);
  await page.waitForFunction(() => !!(window.__inv && window.__inv.tl), null, { polling: 100, timeout: 10000 });
  await page.evaluate(() => document.fonts.ready.then(() => 1));
  await page.waitForTimeout(600);
  const out = (n) => path.resolve(__dirname, `shots/${vp}-${n}.png`);
  await page.screenshot({ path: out('00-fechado') });
  await page.click('.hit');
  await page.evaluate(() => { window.__inv.tl.pause(); });
  const labels = await page.evaluate(() => ({ ...window.__inv.tl.labels, end: window.__inv.tl.duration() }));
  console.log('labels', JSON.stringify(labels));
  const stops = [
    ['01-selo', labels.press + 0.3],
    ['02-trinca', labels.crack + 0.3],
    ['03-aba-inicio', labels.open + 0.5],
    ['04-aba-90', labels.open + 0.93],
    ['05-aba-aberta', labels.open + 1.6],
    ['06-carta-saindo', labels.emerge + 0.9],
    ['07-carta-fora', labels.emerge + 2.2],
    ['08-expandindo', labels.expand + 0.6],
    ['09-revelando', labels.reveal + 0.4],
  ];
  const probe = () => {
    const q = (s) => document.querySelector(s);
    const tr = (s) => getComputedStyle(q(s)).transform;
    const rect = (s) => { const r = q(s).getBoundingClientRect(); return [Math.round(r.top), Math.round(r.bottom), Math.round(r.left), Math.round(r.right)]; };
    return { phase: window.__inv.phase, flap: tr('.env-flap'), sideL: tr('.env-side-left'), sideR: tr('.env-side-right'), bottom: tr('.env-bottom'), letter: rect('.letter'), body: rect('.env-body') };
  };
  for (const [name, t] of stops) {
    await page.evaluate((t) => { window.__inv.tl.seek(t, false); }, t);
    await page.waitForTimeout(120);
    console.log(name, JSON.stringify(await page.evaluate(probe)));
    await page.screenshot({ path: out(name) });
  }
  await page.evaluate(() => { window.__inv.tl.play(); });
  await page.waitForFunction(() => window.__inv.phase === 'completed', null, { timeout: 8000 });
  await page.waitForTimeout(1200);
  await page.screenshot({ path: out('10-completo') });
  // rolagem até o fim, em passos, revelando blocos
  const H = await page.evaluate(() => document.querySelector('.letter').scrollHeight);
  let i = 0;
  for (let y = h * 0.85; y < H; y += h * 0.85) {
    await page.evaluate((y) => { document.querySelector('.letter').scrollTo(0, y); }, y);
    await page.waitForTimeout(1300);
    await page.screenshot({ path: out(`11-rolagem-${++i}`) });
  }
  const hidden = await page.evaluate(() => Array.from(document.querySelectorAll('[data-reveal]')).filter((e) => getComputedStyle(e).opacity < 0.99).length);
  const overflowX = await page.evaluate(() => { const l = document.querySelector('.letter'); return l.scrollWidth - l.clientWidth; });
  console.log('itens ainda ocultos após rolar:', hidden, '| overflow horizontal:', overflowX, '| altura do conteúdo:', H);
  console.log('erros:', errors.length ? errors : 'nenhum');
  await browser.close();
})();
