const { chromium } = require('playwright');
const path = require('path');
const D = path.resolve(__dirname, '../dist');
const ok = (c, m) => console.log((c ? '  OK   ' : '  FALHA') + ' ' + m);
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const page = await ctx.newPage(); const errs = [];
  page.on('pageerror', (e) => errs.push(e.message));
  await page.goto('file://' + D + '/convite-v4-video-standalone.html#gerador');
  await page.waitForSelector('.gen');
  await page.fill('input[placeholder="Ex.: Maria Clara"]', 'Juliano Motta');
  await page.fill('input[type="date"]', '2026-12-05');
  await page.fill('input[type="time"]', '10:30');
  await page.fill('input[inputmode="decimal"]', '1.200,00');
  await page.fill('input[inputmode="url"]', 'https://julianogalaxy.github.io/convite-botox-day/');
  const link = await page.textContent('.gen-out code');
  const msg = await page.inputValue('textarea[readonly]');
  console.log('LINK: ' + link + '  (' + link.length + ' caracteres)\n---\n' + msg + '\n---');
  ok(!/1\.200|R\$/.test(msg), 'mensagem sem valor');
  for (const [h, exp] of [[link.split('#')[1], { name: 'Juliano Motta', meta: '10h30', day: '5', price: '1.200,00' }], ['José-Antônio.1912.0900', { name: 'José Antônio', meta: '9h', day: '19' }], ['Maria', { name: 'Maria' }], ['n=Ana&d=2026-12-12&h=14:30&v=89000', { name: 'Ana', meta: '14h30', day: '12', price: '890,00' }]]) {
    const p = await ctx.newPage(); p.on('pageerror', (e) => errs.push(e.message));
    await p.goto('file://' + D + '/convite-v4-video-standalone.html?semanimacao#' + h);
    await p.waitForSelector('.vmsg');
    const env = await p.textContent('.vmsg');
    await p.click('.hit');
    await p.waitForFunction(() => document.querySelector('.vscene').dataset.phase === 'completed', null, { timeout: 8000 });
    const r = await p.evaluate(() => ({ day: document.querySelector('.d-day').textContent.trim(), meta: document.querySelector('.d-meta').textContent, offer: document.querySelector('.offer')?.textContent || '' }));
    ok(env.startsWith(exp.name + ', preparamos') && (!exp.day || r.day === exp.day) && (!exp.meta || r.meta.includes(exp.meta)) && (exp.price ? r.offer.includes(exp.price) : !r.offer), `#${h} → "${env.slice(0, 30)}…", dia ${r.day}, ${r.meta}${r.offer ? ', ' + r.offer.match(/R\$\s?[\d.,]+/)[0] : ''}`);
    await p.close();
  }
  ok(errs.length === 0, 'sem erros de JS ' + errs.join(';'));
  await b.close();
})();
