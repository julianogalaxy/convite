// Validação da v3 (vídeo). O Chromium de testes não decodifica H.264, então injeta uma cópia WebM idêntica.
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '../dist/convite-v3-video-standalone.html');
const WEBM = process.argv[2];
const SH = path.resolve(__dirname, 'shots');
const ok = (c, m) => console.log((c ? '  OK   ' : '  FALHA') + ' ' + m);
(async () => {
  const b = await chromium.launch();
  for (const [w, h] of [[390, 844], [375, 667], [1440, 900]]) {
    const ctx = await b.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 2, isMobile: w < 900, hasTouch: w < 900 });
    const page = await ctx.newPage();
    const errors = [];
    page.on('pageerror', (e) => errors.push(e.message));
    await page.goto(FILE + '?qa#n=Maria%20Clara&d=2026-12-12&h=14:30');
    await page.waitForFunction(() => !!window.__vid, null, { polling: 100 });
    if (WEBM) await page.evaluate((u) => { const v = document.querySelector('video'); v.src = u; v.load(); }, 'file://' + WEBM);
    await page.waitForTimeout(800);
    await page.screenshot({ path: `${SH}/v3-${w}-0-inicio.png` });
    await page.click('.hit');
    const shots = [[3.0, '1-abrindo'], [5.6, '2-cartao'], [6.35, '3-handoff'], [6.75, '4-carta-sobre-cartao'], [7.3, '5-expandindo'], [7.8, '6-expandindo']];
    const t0 = Date.now();
    let vt = 0;
    for (const [t, n] of shots) {
      while ((Date.now() - t0) / 1000 < t) await page.waitForTimeout(20);
      vt = await page.evaluate(() => document.querySelector('video').currentTime);
      await page.screenshot({ path: `${SH}/v3-${w}-${n}.png` });
    }
    await page.waitForFunction(() => document.querySelector('.scene').dataset.phase === 'completed', null, { timeout: 8000 });
    await page.waitForTimeout(900);
    await page.screenshot({ path: `${SH}/v3-${w}-7-convite.png` });
    const st = await page.evaluate(() => ({ name: document.querySelector('.eyebrow').textContent, meta: document.querySelector('.d-meta').textContent, ox: document.querySelector('.letter').scrollWidth - document.querySelector('.letter').clientWidth }));
    ok(errors.length === 0 && st.ox <= 0 && /Maria Clara/.test(st.name) && /14h30/.test(st.meta), `${w}x${h}: vídeo em ${vt.toFixed(2)} s no último quadro, convite personalizado (${st.name} · ${st.meta}), overflow ${st.ox}, erros ${errors.length}`);
    // reinício
    await page.evaluate(() => document.querySelector('.replay').scrollIntoView({ block: 'center' }));
    await page.waitForTimeout(400);
    await page.click('.replay');
    await page.waitForTimeout(800);
    ok(await page.evaluate(() => document.querySelector('.scene').dataset.phase === 'idle' && document.querySelector('video').currentTime === 0), `${w}x${h}: reinício volta ao início do vídeo`);
    await ctx.close();
  }
  // sem vídeo decodificável (H.264 ausente): segue para o convite sem travar
  const ctx = await b.newContext({ viewport: { width: 390, height: 844 } });
  const p = await ctx.newPage();
  await p.goto(FILE);
  await p.click('.hit');
  await p.waitForFunction(() => document.querySelector('.scene').dataset.phase === 'completed', null, { timeout: 12000 });
  ok(true, 'sem suporte ao vídeo: vai direto ao convite com transição, sem travar');
  await b.close();
})();
