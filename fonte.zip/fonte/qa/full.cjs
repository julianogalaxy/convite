// Validação obrigatória: mecânica, fases, toques repetidos, reinício, movimento reduzido,
// raspadinha, viewports, erros de JS e desempenho com CPU limitada.
const { chromium } = require('playwright');
const path = require('path');
const FILE = 'file://' + path.resolve(__dirname, '../dist/convite-v2-standalone.html');
const SHOTS = path.resolve(__dirname, 'shots');
const ok = (c, m) => console.log((c ? '  OK   ' : '  FALHA') + ' ' + m);

async function open(browser, w, h, opts = {}) {
  const ctx = await browser.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: opts.dpr || 2, isMobile: w < 900, hasTouch: w < 900, reducedMotion: opts.reduced ? 'reduce' : 'no-preference' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.addInitScript(() => {
    window.__phases = [];
    const t0 = performance.now();
    new MutationObserver(() => {
      const s = document.querySelector('.scene');
      if (s && window.__phases[window.__phases.length - 1]?.p !== s.dataset.phase) window.__phases.push({ p: s.dataset.phase, t: Math.round(performance.now() - t0) });
    }).observe(document, { subtree: true, attributes: true, attributeFilter: ['data-phase'] });
  });
  await page.goto(FILE + '?qa');
  await page.waitForFunction(() => !!(window.__inv && window.__inv.tl), null, { polling: 100, timeout: 10000 });
  await page.evaluate(() => document.fonts.ready.then(() => 1));
  await page.waitForTimeout(400);
  return { ctx, page, errors };
}

const rect = (page, s) => page.evaluate((s) => { const r = document.querySelector(s).getBoundingClientRect(); return { t: r.top, b: r.bottom, l: r.left, r: r.right, w: r.width, h: r.height }; }, s);

(async () => {
  const browser = await chromium.launch();

  console.log('\n[1] Viewports: envelope fechado, sem sobreposição, abertura completa, sem rolagem lateral');
  for (const [w, h] of [[320, 568], [375, 667], [360, 780], [390, 844], [430, 932], [768, 1024], [1440, 900], [844, 390]]) {
    const { ctx, page, errors } = await open(browser, w, h);
    const env = await rect(page, '.env-body');
    const msg = await rect(page, '.closed-msg');
    const hint = await rect(page, '.tap-hint span');
    const seal = await rect(page, '.seal');
    await page.screenshot({ path: `${SHOTS}/vp-${w}x${h}-fechado.png` });
    await page.click('.hit');
    await page.waitForTimeout(2900);
    await page.screenshot({ path: `${SHOTS}/vp-${w}x${h}-carta.png` });
    const letterMid = await rect(page, '.letter');
    await page.waitForFunction(() => window.__inv.phase === 'completed', null, { timeout: 12000 });
    await page.waitForTimeout(900);
    await page.screenshot({ path: `${SHOTS}/vp-${w}x${h}-aberto.png` });
    const m = await page.evaluate(() => { const l = document.querySelector('.letter'); return { ox: l.scrollWidth - l.clientWidth, docx: document.documentElement.scrollWidth - innerWidth }; });
    const fit = env.t >= 0 && env.b <= h && env.l >= 0 && env.r <= w;
    ok(fit && msg.b < env.t - 4 && hint.t > env.b && errors.length === 0 && m.ox <= 0 && m.docx <= 0 && letterMid.t >= -2,
      `${w}x${h}: envelope ${Math.round(env.w)}x${Math.round(env.h)} (topo ${Math.round(env.t)}, base ${Math.round(env.b)}), texto termina em ${Math.round(msg.b)}, dica começa em ${Math.round(hint.t)}, selo ${Math.round(seal.w)}px, carta saindo com topo em ${Math.round(letterMid.t)}, overflow ${m.ox}/${m.docx}, erros ${errors.length}`);
    await ctx.close();
  }

  console.log('\n[2] Fases em tempo real, duração total e toques repetidos bloqueados');
  {
    const { ctx, page, errors } = await open(browser, 390, 844);
    await page.click('.hit');
    // toques repetidos durante a animação
    for (const d of [80, 250, 600, 1500]) { await page.waitForTimeout(d); await page.mouse.click(195, 420); }
    const prog = [];
    for (let i = 0; i < 6; i++) { prog.push(await page.evaluate(() => window.__inv.tl.progress())); await page.waitForTimeout(250); }
    await page.waitForFunction(() => window.__inv.phase === 'completed', null, { timeout: 12000 });
    const ph = await page.evaluate(() => window.__phases);
    const seq = ['idle', ...ph.map((x) => x.p)].join(' > ');
    const start = ph.find((x) => x.p === 'seal-interaction').t, end = ph.find((x) => x.p === 'completed').t;
    ok(seq === 'idle > seal-interaction > opening > letter-emerging > revealing > completed', 'sequência: ' + seq);
    ok(prog.every((v, i) => i === 0 || v >= prog[i - 1]), 'progresso monotônico com toques repetidos: ' + prog.map((v) => v.toFixed(2)).join(' '));
    const tlDur = await page.evaluate(() => window.__inv.tl.duration() / window.__inv.tl.timeScale());
    ok(tlDur >= 4 && tlDur <= 9, `duração configurada da timeline: ${tlDur.toFixed(2)} s; do toque até "completed": ${((end - start) / 1000).toFixed(2)} s`);
    ok(errors.length === 0, 'sem erros de JS');

    console.log('\n[3] Raspadinha da foto e reinício discreto');
    const ring = await page.evaluate(() => { const el = document.querySelector('.oval-ring'); el.scrollIntoView({ block: 'center' }); const r = el.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; });
    await page.waitForTimeout(1200);
    const r2 = await page.evaluate(() => { const r = document.querySelector('.oval-ring').getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; });
    await page.mouse.move(r2.x + r2.w * 0.2, r2.y + r2.h * 0.2); await page.mouse.down();
    for (let i = 0; i <= 14; i++) { const fy = 0.15 + 0.7 * (i / 14); for (const fx of [0.15, 0.85]) await page.mouse.move(r2.x + r2.w * fx, r2.y + r2.h * fy, { steps: 4 }); }
    await page.mouse.up();
    await page.waitForTimeout(1100);
    ok(await page.evaluate(() => !!document.querySelector('.oval.revealed')), 'raspar revela a foto');
    await page.screenshot({ path: `${SHOTS}/raspadinha.png` });
    await page.evaluate(() => document.querySelector('.replay').scrollIntoView({ block: 'center' }));
    await page.waitForTimeout(500);
    await page.click('.replay');
    await page.waitForTimeout(900);
    const st = await page.evaluate(() => ({ phase: window.__inv.phase, hit: !!document.querySelector('.hit'), clip: document.querySelector('.letter').style.clipPath, flap: getComputedStyle(document.querySelector('.env-flap')).display }));
    ok(st.phase === 'idle' && st.hit && st.clip.startsWith('inset') && st.flap !== 'none', 'reinício volta ao envelope fechado: ' + JSON.stringify(st));
    await page.screenshot({ path: `${SHOTS}/reinicio.png` });
    await page.click('.hit');
    await page.waitForFunction(() => window.__inv.phase === 'completed', null, { timeout: 12000 });
    ok(true, 'segunda abertura completa após reinício');
    await ctx.close();
  }

  console.log('\n[4] Sistema com "reduzir movimento" ativo: a abertura 3D continua acontecendo');
  {
    const { ctx, page, errors } = await open(browser, 390, 844, { reduced: true });
    await page.click('.hit');
    await page.waitForTimeout(1100);
    const midFlap = await page.evaluate(() => getComputedStyle(document.querySelector('.env-flap')).transform);
    await page.screenshot({ path: `${SHOTS}/reduzido-abrindo.png` });
    ok(midFlap !== 'none' && midFlap.startsWith('matrix3d'), 'aba girando em 3D mesmo com reduzir movimento: ' + midFlap.slice(0, 60));
    await page.waitForFunction(() => window.__inv.phase === 'completed', null, { timeout: 12000 });
    for (let y = 600; y < 3200; y += 600) { await page.evaluate((y) => { document.querySelector('.letter').scrollTo(0, y); }, y); await page.waitForTimeout(900); }
    const hidden = await page.evaluate(() => Array.from(document.querySelectorAll('[data-reveal]')).filter((e) => getComputedStyle(e).opacity < 0.99).length);
    ok(hidden === 0 && errors.length === 0, `todos os blocos visíveis após rolar (${hidden} ocultos), erros ${errors.length}`);
    await page.screenshot({ path: `${SHOTS}/reduzido.png` });
    await ctx.close();
  }

  console.log('\n[5] Desempenho: abertura em tempo real com CPU 4x mais lenta (celular intermediário)');
  {
    const { ctx, page } = await open(browser, 390, 844, { dpr: 3 });
    const cdp = await ctx.newCDPSession(page);
    await cdp.send('Emulation.setCPUThrottlingRate', { rate: 4 });
    await page.evaluate(() => { window.__ft = []; let last = performance.now(); const f = (t) => { window.__ft.push(t - last); last = t; if (window.__inv.phase !== 'completed') requestAnimationFrame(f); }; requestAnimationFrame(f); });
    await page.click('.hit');
    await page.waitForFunction(() => window.__inv.phase === 'completed', null, { timeout: 15000 });
    const ft = await page.evaluate(() => window.__ft.slice(2));
    ft.sort((a, b) => a - b);
    const p = (q) => ft[Math.floor(ft.length * q)].toFixed(1);
    const long = ft.filter((x) => x > 50).length;
    ok(+p(0.95) < 34, `quadros: ${ft.length}, mediana ${p(0.5)} ms, p95 ${p(0.95)} ms, máx ${ft[ft.length - 1].toFixed(1)} ms, quadros > 50 ms: ${long}`);
    await ctx.close();
  }
  await browser.close();
})();
