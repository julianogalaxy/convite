// Build local de arquivo único (substitui `vite build` quando o registro npm não está acessível).
// Usa o esbuild, o mesmo compilador que o Vite usa internamente.
// Saídas:
//   dist/convite-v2-experiencia.html  -> corpo para publicação como artefato
//   dist/convite-v2-standalone.html   -> documento HTML completo, abre direto no navegador
// usa o esbuild instalado junto com o Vite; no ambiente de criação, o binário local
const { build } = await import('esbuild').catch(() => import('/opt/npm-tools/node_modules/esbuild/lib/main.js'));
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const out = join(root, 'dist');
mkdirSync(out, { recursive: true });

async function bundle(entry) {
  const res = await build({
  entryPoints: [join(root, entry)],
  bundle: true,
  write: false,
  outdir: out,
  format: 'iife',
  target: ['es2020', 'safari15', 'chrome100'],
  jsx: 'automatic',
  minify: true,
  legalComments: 'none',
  define: { 'process.env.NODE_ENV': '"production"' },
  loader: { '.webp': 'dataurl', '.woff': 'dataurl', '.woff2': 'dataurl', '.mp4': 'dataurl' },
  nodePaths: [join(root, 'node_modules')],
  logLevel: 'error',
});

  let js = '', css = '';
  for (const f of res.outputFiles) {
    if (f.path.endsWith('.js')) js = f.text;
    else if (f.path.endsWith('.css')) css = f.text;
  }
  return { js: js.replace(/<\/script/gi, '<\\/script'), css: css.replace(/<\/style/gi, '<\\/style') };
}
let { js, css } = await bundle('src/main.tsx');
const pages = {
  convite: { title: 'Convite Botox Day · Experiência', desc: 'Convite digital Botox Day da Dra. Elisângela Mota Magalhães, Hortolândia/SP.', mode: '' },
  video: { title: 'Convite Botox Day · Filme', desc: 'Convite digital Botox Day da Dra. Elisângela Mota Magalhães, Hortolândia/SP.', mode: '' },
  video4: { title: 'Convite Botox Day · Filme 2', desc: 'Convite digital Botox Day da Dra. Elisângela Mota Magalhães, Hortolândia/SP.', mode: '' },
  gerador4: { title: 'Gerador de Convites · Filme 2', desc: 'Uso interno: gera o convite v4 personalizado de cada paciente.', mode: ' data-mode="gerador"' },
  gerador: { title: 'Gerador de Convites Botox Day', desc: 'Uso interno: gera o convite personalizado de cada paciente.', mode: ' data-mode="gerador"' },
};
const head = (pg) => `<title>${pg.title}</title>
<meta name="description" content="${pg.desc}">
<meta name="claude:viewport-fit-sides" content="cover">
<meta name="theme-color" content="#F4EEE6">`;
const body = (pg) => `<div id="root"${pg.mode}></div>
<noscript><p style="font-family:serif;padding:24px;text-align:center">Botox Day · Dra. Elisângela Mota Magalhães · CRO-SP 98531 · Agendamento pelo WhatsApp (19) 4122-0163</p></noscript>`;
const artifact = (pg, b = { js, css }) => `${head(pg)}
<style>${b.css}</style>
${body(pg)}
<script>${b.js}</script>
`;
const standalone = (pg, b = { js, css }) => `<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
${head(pg)}
<style>${b.css}</style>
</head>
<body>
${body(pg)}
<script>${b.js}</script>
</body>
</html>
`;
writeFileSync(join(out, 'convite-v2-experiencia.html'), artifact(pages.convite));
writeFileSync(join(out, 'convite-v2-standalone.html'), standalone(pages.convite));
writeFileSync(join(out, 'gerador-convites.html'), artifact(pages.gerador));
writeFileSync(join(out, 'gerador-convites-standalone.html'), standalone(pages.gerador));
const vb = await bundle('src/main-video.tsx');
writeFileSync(join(out, 'convite-v3-video.html'), artifact(pages.video, vb));
writeFileSync(join(out, 'convite-v3-video-standalone.html'), standalone(pages.video, vb));
const vb4 = await bundle('src/main-video4.tsx');
writeFileSync(join(out, 'convite-v4-video.html'), artifact(pages.video4, vb4));
writeFileSync(join(out, 'convite-v4-video-standalone.html'), standalone(pages.video4, vb4));
writeFileSync(join(out, 'gerador-v4.html'), artifact(pages.gerador4, vb4));
writeFileSync(join(out, 'gerador-v4-standalone.html'), standalone(pages.gerador4, vb4));
console.log(`video ${(vb.js.length / 1024).toFixed(0)} KB · js ${(js.length / 1024).toFixed(1)} KB · css ${(css.length / 1024).toFixed(1)} KB`);
